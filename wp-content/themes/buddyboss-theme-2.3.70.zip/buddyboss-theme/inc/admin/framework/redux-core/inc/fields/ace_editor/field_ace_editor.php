<?php
// Shim file for bad theme developers.
