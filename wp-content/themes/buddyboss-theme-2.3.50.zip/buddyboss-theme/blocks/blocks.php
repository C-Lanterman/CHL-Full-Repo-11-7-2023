<?php
/**
 * BuddyBoss Theme Blocks
 *
 * Include all registered blocks to appear in the backend.
 *
 * @package buddyboss-theme
 */

// Include the BuddyPanel block.
require_once __DIR__ . '/buddypanel/index.php';
