<?php
/**
 * BuddyBoss OneSignal Template Functions.
 *
 * @package BuddyBoss\OneSignal\Templates
 * @since 2.0.3
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
