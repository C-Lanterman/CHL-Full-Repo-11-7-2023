<?php
$emercury_fields = array();

$emercury_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email',
);

$emercury_fields['first_name'] = array(
	'crm_label'   => 'First Name',
	'crm_field'   => 'first_name',
	'crm_field_2' => 'user_field_1',
);

$emercury_fields['last_name'] = array(
	'crm_label'   => 'Last Name',
	'crm_field'   => 'last_name',
	'crm_field_2' => 'user_field_2',
);

