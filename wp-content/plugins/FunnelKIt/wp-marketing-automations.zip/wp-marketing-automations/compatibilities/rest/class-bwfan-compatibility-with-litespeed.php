<?php

/**
 * LiteSpeed Cache
 *
 * https://wordpress.org/plugins/litespeed-cache/
 */
if ( ! class_exists( 'BWFAN_Compatibility_With_LightSpeed' ) ) {
	class BWFAN_Compatibility_With_LightSpeed {

		public function __construct() {
			/** Adding FKA endpoints for exclude url from cache */
			$exc_uris = get_option( 'litespeed.conf.cache-exc' );
			add_filter( 'pre_option_litespeed.conf.cache-exc', function ( $value ) use ( $exc_uris ) {
				$exc_uris = json_decode( $exc_uris, true );
				$exc_uris = is_array( $exc_uris ) ? $exc_uris : [];

				$exc_uris[] = "^/wp-json/autonami-admin/";
				$exc_uris[] = "^/wp-json/woofunnels/";
				$exc_uris[] = "^/wp-json/funnelkit-automations/";

				$exc_uris = array_unique( $exc_uris );
				sort( $exc_uris );

				return wp_json_encode( $exc_uris );
			}, PHP_INT_MAX );

			/** Disable cache for administrator role */
			$exc_roles = get_option( 'litespeed.conf.cache-exc_roles' );
			add_filter( 'pre_option_litespeed.conf.cache-exc_roles', function ( $value ) use ( $exc_roles ) {
				$exc_roles   = json_decode( $exc_roles, true );
				$exc_roles   = is_array( $exc_roles ) ? $exc_roles : [];
				$exc_roles[] = "administrator";

				$exc_roles = array_unique( $exc_roles );
				sort( $exc_roles );

				return wp_json_encode( $exc_roles );
			}, PHP_INT_MAX );
		}
	}

	if ( defined( 'LSCWP_V' ) ) {
		new BWFAN_Compatibility_With_LightSpeed();
	}
}
