<?php

abstract class BWFAN_Step_Run_Controller {
	public $step_id = 0;
	public $step_data = array();
	public $action_data = array();

	public $automation_id = 0;
	public $contact_id = 0;

}
