<?php

class BWFAN_Model_Settings extends BWFAN_Model {
	static $primary_key = 'ID';
}
