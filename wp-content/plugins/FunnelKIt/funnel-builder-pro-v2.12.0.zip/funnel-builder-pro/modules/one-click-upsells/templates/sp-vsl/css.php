<?php
$css = $this->internal_css;
global $wfocu_css_output, $wfocu_media_css_output;
