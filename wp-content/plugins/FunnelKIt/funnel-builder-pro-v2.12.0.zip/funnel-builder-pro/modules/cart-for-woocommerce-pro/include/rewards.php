<?php

namespace FKCart\Pro;

use FKCart\Compatibilities\Compatibility;
use FKCart\Includes\Data as Data;
use FKCart\Includes\Front;

class Rewards {
	private static $instance = null;

	private function __construct() {
		add_action( 'wp', [ $this, 'maybe_remove_free_gifts' ] );
		add_action( 'woocommerce_cart_loaded_from_session', [ $this, 'update_free_gift' ], 98 );
		add_action( 'woocommerce_before_calculate_totals', [ $this, 'update_free_gift' ], 98 );
		add_action( 'woocommerce_calculate_totals', [ $this, 'update_reward' ], 99 );
		add_filter( 'woocommerce_package_rates', [ $this, 'apply_free_shipping' ] );
		add_filter( 'woocommerce_cart_item_remove_link', [ $this, 'do_not_allow_delete_free_gift' ], 10, 2 );
		add_filter( 'wfacp_enable_delete_item', [ $this, 'aero_disabled_delete_icon' ], 10, 2 );
		add_filter( 'wfacp_mini_cart_enable_delete_item', [ $this, 'aero_disabled_delete_icon' ], 10, 2 );
		add_action( 'woocommerce_checkout_update_order_review', [ $this, 'update_chosen_shipping_methods' ], 20 );
		add_filter( 'pre_option_woocommerce_shipping_cost_requires_address', [ $this, 'disable_hide_shipping_method_until_address' ] );
		add_action( 'woocommerce_removed_coupon', [ $this, 'stored_removed_coupon' ] );
		add_action( 'woocommerce_cart_emptied', [ $this, 'unset_removed_coupon' ] );
	}

	/**
	 * @return Rewards
	 */
	public static function getInstance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Update free gift product price to 0
	 *
	 * @param $cart
	 *
	 * @return mixed
	 */
	public function update_free_gift( $cart ) {
		$contents = $cart->get_cart_contents();
		foreach ( $contents as $cart_item_key => $cart_item ) {
			$cart->cart_contents[ $cart_item_key ] = $this->set_price_to_zero_for_free_gift( $cart_item );
		}

		return $cart;
	}

	/**
	 * Modify free gift cart item data
	 * Set price 0 and don't allow qty increment
	 *
	 * @param $cart_items
	 *
	 * @return mixed
	 */
	protected function set_price_to_zero_for_free_gift( $cart_items ) {
		if ( ! isset( $cart_items['_fkcart_free_gift'] ) ) {
			return $cart_items;
		}

		$cart_items['data']->set_sold_individually( true ); // do not allow quantity increment for free gift
		$cart_items['data']->set_price( 0 );

		return $cart_items;
	}

	/**
	 * Don't allow deleting of free gifts products
	 *
	 * @param $link
	 * @param $cart_item_key
	 *
	 * @return mixed|string
	 */
	public function do_not_allow_delete_free_gift( $link, $cart_item_key ) {
		$cart_item = WC()->cart->get_cart_item( $cart_item_key );
		if ( isset( $cart_item['_fkcart_free_gift'] ) ) {
			return '';
		}

		return $link;
	}

	/**
	 * Make cart empty when all free gift available inside the cart
	 *
	 * @return void
	 */
	public function maybe_remove_free_gifts() {
		if ( is_null( WC()->cart ) ) {
			return;
		}

		$cart_count = WC()->cart->get_cart_contents_count();
		$free_items = array_filter( WC()->cart->get_cart_contents(), function ( $cart_item ) {
			return isset( $cart_item['_fkcart_free_gift'] );
		} );
		if ( count( $free_items ) > 0 && count( $free_items ) === $cart_count ) {
			WC()->cart->empty_cart();
		}
	}

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function update_reward() {
		$rewards = self::get_rewards();
		if ( empty( $rewards ) || is_null( WC()->cart ) ) {
			return;
		}

		if ( wp_doing_ajax() ) {
			/** Remove redirect after add to cart */
			add_filter( 'wp_redirect', '__return_false', PHP_INT_MAX );
		}

		$previous_notices = wc_get_notices();
		/** Remove action */
		remove_action( 'woocommerce_calculate_totals', [ $this, 'update_reward' ], 99 );

		$coupon_remove = $rewards['coupons']['remove'];
		$coupon_add    = $rewards['coupons']['add'];
		$free_shipping = $rewards['free_shipping'];

		$removed_coupons = WC()->session->get( '_fkcart_removed_coupons', [] );

		/** Remove coupons if needed */
		if ( is_array( $coupon_remove ) && count( $coupon_remove ) > 0 ) {
			foreach ( $coupon_remove as $rm_coupon_code ) {
				if ( WC()->cart->has_discount( $rm_coupon_code ) ) {
					WC()->cart->remove_coupon( $rm_coupon_code );
				}
			}
		}

		/** Add coupons if needed */
		if ( is_array( $coupon_add ) && count( $coupon_add ) > 0 ) {
			foreach ( $coupon_add as $add_coupon_code ) {
				if ( WC()->cart->has_discount( $add_coupon_code ) || isset( $removed_coupons[ strtolower( $add_coupon_code ) ] ) ) {
					continue;
				}
				WC()->cart->add_discount( $add_coupon_code );
			}
		}

		$gift_add    = $rewards['gifts']['add'];
		$gift_remove = $rewards['gifts']['remove'];

		/** @var \WC_Product $product */
		$gift_remove = array_unique( array_merge( $gift_remove, $gift_add ) );
		sort( $gift_remove );

		/** Remove all gift products to keep code simple */
		if ( is_array( $gift_remove ) && count( $gift_remove ) > 0 ) {
			$contents = WC()->cart->get_cart_contents();
			foreach ( $contents as $cart_item_key => $cart_item ) {
				if ( ! isset( $cart_item['_fkcart_free_gift'] ) ) {
					continue;
				}

				$product = $cart_item['data'];
				if ( in_array( $product->get_id(), $gift_remove ) || in_array( $product->get_parent_id(), $gift_remove ) ) {
					$status = WC()->cart->remove_cart_item( $cart_item_key );
					if ( false !== $status ) {
						unset( WC()->cart->removed_cart_contents[ $cart_item_key ] );
					}
				}
				unset( $product );
			}
		}

		/** Add all gift products to the cart */
		if ( is_array( $gift_add ) && count( $gift_add ) > 0 ) {
			foreach ( $gift_add as $add ) {
				$product = wc_get_product( $add );
				if ( ! $product instanceof \WC_Product ) {
					continue;
				}

				$product_id   = $product->get_id();
				$variation_id = 0;
				if ( fkcart_is_variation_product_type( $product->get_type() ) ) {
					$product_id   = $product->get_parent_id();
					$variation_id = $product->get_id();
				}

				WC()->cart->add_to_cart( $product_id, 1, $variation_id, [], [ '_fkcart_free_gift' => 1 ] );
			}
		}

		if ( ! is_null( WC()->session ) ) {
			WC()->session->__unset( '_fkcart_free_shipping_methods' );
			if ( $free_shipping ) {
				// Set a key for free shipping reward
				WC()->session->set( '_fkcart_free_shipping_methods', $free_shipping );
				if ( ! wp_doing_ajax() ) {
					WC()->session->set( 'chosen_shipping_methods', [ $free_shipping ] );
				}
			}
		}

		wc_clear_notices();
		WC()->session->set( 'wc_notices', $previous_notices );
	}

	/**
	 * Modify saved rewards and return
	 *
	 * @return array|void
	 */
	public static function get_rewards() {
		if ( false === Data::is_rewards_enabled() ) {
			return;
		}

		$rewards = Data::get_value( 'reward' );
		if ( empty( $rewards ) ) {
			return;
		}

		$wc_coupons_enable  = wc_coupons_enabled();
		$wc_shipping_enable = wc_shipping_enabled();

		$rewards_new = $rewards;

		foreach ( $rewards as $r => $reward ) {
			if ( 'freeshipping' === $reward['type'] ) {
				if ( ! $wc_shipping_enable ) {
					unset( $rewards_new[ $r ] );
					continue;
				}
				$shipping_data = apply_filters( 'fkcart_free_shipping', self::get_shipping_min_amount() );
				if ( false === $shipping_data ) {
					unset( $rewards_new[ $r ] );
					continue;
				}
				$reward['amount']          = $shipping_data['min_amount'];
				$reward['shipping_method'] = $shipping_data['method_id'];
			}
			if ( 'discount' === $reward['type'] && false === $wc_coupons_enable ) {
				unset( $rewards_new[ $r ] );
				continue;
			}
			if ( isset( $reward['amount'] ) ) {
				$reward['amount'] = Compatibility::get_fixed_currency_price( $reward['amount'] );
			}
			$rewards_new[ $r ] = $reward;
		}

		if ( empty( $rewards_new ) ) {
			return;
		}
		$rewards = $rewards_new;
		unset( $rewards_new );

		/** Sort array based on price */
		usort( $rewards, function ( $item1, $item2 ) {
			return intval( $item1['amount'] ) <=> intval( $item2['amount'] );
		} );

		/** Get max amount milestone of progress bar */
		$max_amount = array_column( $rewards, 'amount' );
		if ( count( $max_amount ) > 0 ) {
			$max_amount = max( $max_amount );
		}
		$max_amount = ( is_array( $max_amount ) || empty( $max_amount ) || intval( $max_amount ) < 1 ) ? 1 : $max_amount;

		$front         = Front::get_instance();
		$subtotal      = $front->get_subtotal_row( true );
		$title         = '';
		$free_shipping = false;

		$coupons    = [ 'add' => [], 'remove' => [] ];
		$free_gifts = [ 'add' => [], 'remove' => [] ];

		foreach ( $rewards as $key => $reward ) {
			$amount_checked                    = isset( $reward['amount'] ) && floatval( $reward['amount'] ) >= 0;
			$rewards[ $key ]['achieved']       = $amount_checked && ( round( $reward['amount'], 2 ) <= $subtotal );
			$rewards[ $key ]['pending_amount'] = $amount_checked ? ( ( round( $reward['amount'], 2 ) < $subtotal ) ? 0 : round( $reward['amount'], 2 ) - $subtotal ) : 0;
			$rewards[ $key ]['progress_width'] = $amount_checked ? ( ( round( $reward['amount'], 2 ) * 100 ) / $max_amount ) : 0;

			if ( empty( $title ) && false === $rewards[ $key ]['achieved'] ) {
				$title = isset( $reward['title'] ) ? $reward['title'] : '';
				$title = str_replace( '{{remaining_amount}}', wc_price( $rewards[ $key ]['pending_amount'] ), $title );
				$title = preg_replace( '/~([^~]+)~/', '<div class="fkcart-reward-milestone">$1</div>', $title );
			}

			if ( 'discount' === strval( $reward['type'] ) && isset( $reward['coupon'] ) ) {
				if ( true === $rewards[ $key ]['achieved'] ) {
					$coupons['add'][] = $reward['coupon'];
				} else {
					$coupons['remove'][] = $reward['coupon'];
				}
				continue;
			}
			if ( 'freegift' === strval( $reward['type'] ) && isset( $reward['freeProduct'] ) ) {
				if ( ! is_array( $reward['freeProduct'] ) || 0 === count( $reward['freeProduct'] ) ) {
					continue;
				}
				$free_products = array_column( $reward['freeProduct'], 'key' );
				if ( true === $rewards[ $key ]['achieved'] ) {
					$free_gifts['add'] = array_merge( $free_gifts['add'], $free_products );
				} else {
					$free_gifts['remove'] = array_merge( $free_gifts['remove'], $free_products );
				}
				continue;
			}
			if ( false === $free_shipping && 'freeshipping' === strval( $reward['type'] ) && true === $rewards[ $key ]['achieved'] ) {
				$free_shipping = isset( $rewards[ $key ]['shipping_method'] ) ? $rewards[ $key ]['shipping_method'] : false;
			}
		}

		$progress_width = 0;
		if ( intval( $subtotal ) > 0 ) {
			$progress_width = ( ( $subtotal * 100 ) / $max_amount ) > 100 ? 100 : number_format( ( ( $subtotal * 100 ) / $max_amount ), 2 );
		}
		if ( $progress_width >= 100 ) {
			$title = Data::get_value( 'reward_title' );
		}

		return [
			'max_amount'    => $max_amount,
			'title'         => $title,
			'coupons'       => $coupons,
			'gifts'         => $free_gifts,
			'free_shipping' => $free_shipping,
			'rewards'       => $rewards,
			'progress_bar'  => $progress_width
		];
	}

	/**
	 * Get current shipping method of user with current zone
	 *
	 * @return false|array
	 */
	public static function get_shipping_min_amount() {
		$geolocation = Geolocation::geolocate_ip( Geolocation::get_ip_address(), true );

		if ( empty( $geolocation['country'] ) ) {
			return false;
		}

		$country   = strtoupper( wc_clean( $geolocation['country'] ) );
		$state     = strtoupper( wc_clean( $geolocation['state'] ) );
		$continent = strtoupper( wc_clean( WC()->countries->get_continent_code_for_country( $geolocation['country'] ) ) );
		$postcode  = wc_normalize_postcode( $geolocation['postcode'] );

		$zone_cache_key   = \WC_Cache_Helper::get_cache_prefix( 'shipping_zones' ) . 'wc_shipping_zone_' . md5( sprintf( '%s+%s+%s', $country, $state, $postcode ) );
		$matched_zone_key = wp_cache_get( $zone_cache_key, 'shipping_zones' );

		if ( false === $matched_zone_key ) {
			global $wpdb;

			// Work out criteria for our zone search
			$conditions = array();
			// add condition for country code
			$conditions[] = $wpdb->prepare( "( ( location_type = 'country' AND location_code = %s )", $country );
			// OR condition for country & state Combo
			$conditions[] = $wpdb->prepare( "OR ( location_type = 'state' AND location_code = %s )", $country . ':' . $state );
			// OR condition for Continents
			$conditions[] = $wpdb->prepare( "OR ( location_type = 'continent' AND location_code = %s )", $continent );

			// OR condition for Other location Type
			$conditions[] = "OR ( location_type IS NULL ) )";

			// Postcode range and wildcard matching
			$get_zipcode_locations = $wpdb->get_results( "SELECT zone_id, location_code FROM {$wpdb->prefix}woocommerce_shipping_zone_locations WHERE location_type = 'postcode';" );

			if ( $get_zipcode_locations ) {
				$zone_ids_with_postcode_rules = array_map( 'absint', wp_list_pluck( $get_zipcode_locations, 'zone_id' ) );
				$matches                      = wc_postcode_location_matcher( $postcode, $get_zipcode_locations, 'zone_id', 'location_code', $country );
				$do_not_match                 = array_unique( array_diff( $zone_ids_with_postcode_rules, array_keys( $matches ) ) );

				if ( ! empty( $do_not_match ) ) {
					$conditions[] = "AND zones.zone_id NOT IN (" . implode( ',', $do_not_match ) . ")";
				}
			}

			// Get matching zones
			$matched_zone_key = $wpdb->get_var( "SELECT zones.zone_id FROM {$wpdb->prefix}woocommerce_shipping_zones as zones
				INNER JOIN {$wpdb->prefix}woocommerce_shipping_zone_locations as locations ON zones.zone_id = locations.zone_id AND location_type != 'postcode'
				WHERE " . implode( ' ', $conditions ) . "
				ORDER BY zone_order ASC LIMIT 1" );
		}

		$shipping_methods                = new  \WC_Shipping_Zone( $matched_zone_key );
		$shipping_methods                = $shipping_methods->get_shipping_methods( true );
		$free_shipping_supported_methods = fkcart_free_shipping_method();
		foreach ( $shipping_methods as $i => $shipping_method ) {
			if ( ! is_numeric( $i ) || 'yes' !== $shipping_method->enabled ) {
				continue;
			}

			if ( ! in_array( $shipping_method->id, $free_shipping_supported_methods ) || in_array( $shipping_method->requires, [ 'coupon', 'both' ] ) ) {
				continue;
			}

			return Compatibility::get_free_shipping( $shipping_method );
		}

		return false;
	}

	/**
	 * Apply Free Shipping  & Unset other available shipping
	 *
	 * @param $rates
	 *
	 * @return array|mixed
	 */
	public function apply_free_shipping( $rates ) {
		if ( empty( $rates ) ) {
			return $rates;
		}

		$free_shipping = WC()->session->get( '_fkcart_free_shipping_methods', '' );
		if ( empty( $free_shipping ) ) {
			return $rates;
		}

		$free_shipping_rate = [];
		foreach ( $rates as $method => $rate ) {
			if ( strval( $rate->id ) === strval( $free_shipping ) ) {
				$free_shipping_rate[ $method ] = $rate;
			}
		}

		if ( empty( $free_shipping_rate ) ) {
			return $rates;
		}

		WC()->session->set( 'chosen_shipping_methods', [ $free_shipping ] );

		return $free_shipping_rate;
	}

	/**
	 * Set shipping method in the WC session
	 *
	 * @return void
	 */
	public function update_chosen_shipping_methods() {
		if ( is_null( WC()->session ) ) {
			return;
		}

		$free_shipping = WC()->session->get( '_fkcart_free_shipping_methods', '' );
		if ( empty( $free_shipping ) ) {
			return;
		}

		WC()->session->set( 'chosen_shipping_methods', [ $free_shipping ] );
	}

	/**
	 * Disable Delete icon for Funnelkit cart free Gift item
	 *
	 * @param $status
	 * @param $cart_item
	 *
	 * @return false|mixed
	 */
	public function aero_disabled_delete_icon( $status, $cart_item ) {
		if ( isset( $cart_item['_fkcart_free_gift'] ) ) {
			$status = false;
		}

		return $status;
	}

	/**
	 * Disable Hide Shipping Method until Complete address setting when Free Shipping Reward Available
	 * @return string
	 */
	public function disable_hide_shipping_method_until_address( $status ) {
		/** If unchecked or WC admin page */
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $status;
		}

		/** If empty WC session */
		if ( is_null( WC()->cart ) || WC()->cart->is_empty() || is_null( WC()->session ) ) {
			return $status;
		}

		$free_shipping = WC()->session->get( '_fkcart_free_shipping_methods', '' );

		return ! empty( $free_shipping ) ? 'no' : $status;
	}

	/**
	 * Save removed coupons in WC session if user removed
	 *
	 * @return void
	 */
	public function stored_removed_coupon( $coupon_code ) {
		$count = ( did_action( 'wc_ajax_remove_coupon' ) || did_action( 'wfacp_before_coupon_removed' ) || did_action( 'wc_ajax_fkcart_remove_coupon' ) );
		if ( false === $count || is_null( WC()->session ) ) {
			return;
		}
		$removed_coupons = WC()->session->get( '_fkcart_removed_coupons', [] );

		$removed_coupons[ strtolower( $coupon_code ) ] = true;

		WC()->session->set( '_fkcart_removed_coupons', $removed_coupons );
	}

	/**
	 * Unset removed coupon session key when cart is emptied
	 *
	 * @return void
	 */
	public function unset_removed_coupon() {
		if ( is_null( WC()->session ) ) {
			return;
		}
		WC()->session->__unset( '_fkcart_removed_coupons' );
	}
}
