<?php
/**
 * Plugin Name: Cart For WooCommerce Pro
 * Plugin URI: https://funnelkit.com/
 * Description: A WooCommerce Cart plugin from FunnelKit.
 * Version: 0.9.0
 * Author: FunnelKit
 */

namespace FKCart\Pro;

class Plugin {
	private static $instance = null;

	private function __construct() {
		add_action( 'funnelkit_cart_loaded', [ $this, 'include_core' ], 15 );
	}

	public function include_core() {
		if ( ! class_exists( 'WFFN_Core' ) ) {
			/** If no FB lite plugin found */
			return;
		}

		include __DIR__ . '/include/geolocation.php';
		include __DIR__ . '/include/upsells.php';
		include __DIR__ . '/include/rewards.php';

		Upsells::getInstance();
		Rewards::getInstance();
	}

	/**
	 * @return Plugin
	 */
	public static function getInstance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

Plugin::getInstance();
