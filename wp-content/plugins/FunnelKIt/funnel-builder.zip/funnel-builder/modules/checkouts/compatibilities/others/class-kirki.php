<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'Kirki_Init' ) ) {

	/**
	 * Initialize Kirki
	 */
	class Kirki_Init {

	}

	class Kirki_Scripts_Registry {


	}
}

