<?php
/**
 * Primary listing vieew
 */
defined( 'ABSPATH' ) || exit; //Exit if accessed directly

?>
<script>
    var bwf_admin_logo = '<?php echo esc_url(plugin_dir_url( WooFunnel_Loader::$ultimate_path ) . 'woofunnels/assets/img/bwf-icon-white-bg.svg'); ?>';
</script>
<div id="wffn-contacts" class="wffn-page"></div>
