<?php
defined( 'ABSPATH' ) || exit; //Exit if accessed directly
/**
 * Section footer
 */
?>
</div>
