<?php

if ( ! class_exists( 'WFFN_Themes_Compatibility' ) ) {
	class WFFN_Themes_Compatibility {

		public function __construct() {

		}

	}

	new WFFN_Themes_Compatibility();
}
