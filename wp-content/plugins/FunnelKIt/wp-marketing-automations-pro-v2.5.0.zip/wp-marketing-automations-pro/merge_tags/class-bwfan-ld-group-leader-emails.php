<?php

class BWFAN_LD_Group_Leader_Emails extends BWFAN_Merge_Tag {

	private static $instance = null;

	public function __construct() {
		$this->tag_name        = 'ld_group_leader_emails';
		$this->tag_description = __( 'Group Leader(s) Emails', 'autonami-automations-pro' );
		add_shortcode( 'bwfan_ld_group_leader_emails', array( $this, 'parse_shortcode' ) );
	}

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Parse the merge tag and return its value.
	 *
	 * @param $attr
	 *
	 * @return mixed|string|void
	 */
	public function parse_shortcode( $attr ) {
		$get_data = BWFAN_Merge_Tag_Loader::get_data();
		if ( true === $get_data['is_preview'] ) {
			return $this->get_dummy_preview();
		}

		$group_id = isset( $get_data['group_id'] ) ? intval( $get_data['group_id'] ) : '';
		if ( ! empty( $group_id ) ) {
			$leaders_emails = $this->get_group_leaders_email( $group_id );
			$emails         = is_array( $leaders_emails ) ? implode( ', ', $leaders_emails ) : '';

			return $this->parse_shortcode_output( $emails, $attr );
		}

		$course_id = isset( $get_data['course_id'] ) ? intval( $get_data['course_id'] ) : '';
		if ( empty( $course_id ) ) {
			return $this->parse_shortcode_output( '', $attr );
		}

		$groups = learndash_get_course_groups( $course_id );
		if ( empty( $groups ) ) {
			return $this->parse_shortcode_output( '', $attr );
		}

		$leader_emails = [];
		foreach ( $groups as $group_id ) {
			$leader_emails = array_unique( array_merge( $leader_emails, $this->get_group_leaders_email( $group_id ) ) );
		}

		$emails = is_array( $leader_emails ) ? implode( ', ', $leader_emails ) : '';

		return $this->parse_shortcode_output( $emails, $attr );
	}

	/**
	 * Show dummy value of the current merge tag.
	 *
	 * @return string
	 */
	public function get_dummy_preview() {
		return 'groupleader@example.com';
	}

	/**
	 * fetching group leader email
	 *
	 * @param $group_id
	 *
	 * @return array
	 */
	public function get_group_leaders_email( $group_id ) {
		$leaders = BWFAN_Learndash_Common::get_group_leaders_by_group_id( $group_id );
		if ( empty( $leaders ) || ! is_array( $leaders ) ) {
			return [];
		}

		$emails = array();
		foreach ( $leaders as $leader ) {
			$user_obj = get_user_by( 'ID', intval( $leader['user_id'] ) );
			if ( ! $user_obj instanceof WP_User ) {
				continue;
			}

			$emails[] = $user_obj->user_email;
		}

		return $emails;
	}
}

/**
 * Register this merge tag to a group.
 */
if ( bwfan_is_learndash_active() ) {
	BWFAN_Merge_Tag_Loader::register( 'learndash_group', 'BWFAN_LD_Group_Leader_Emails', null, 'Learndash' );
}
