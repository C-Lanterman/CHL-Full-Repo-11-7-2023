<?php

class BWFAN_Model_Contact_Note extends BWFAN_Model {

	/**
	 * @param $contact_id
	 * @param int $offset
	 * @param int $limit
	 *
	 * @return array
	 */
	public static function get_contact_notes( $contact_id, $offset = 0, $limit = 0 ) {
		if ( empty( $offset ) && empty( $limit ) ) {
			$query = "SELECT * FROM {table_name} WHERE `cid`='" . $contact_id . "' ORDER BY `created_date` DESC";
		} else {
			$query = "SELECT * FROM {table_name} WHERE `cid`='" . $contact_id . "' ORDER BY `created_date` DESC LIMIT $offset,$limit";
		}

		return self::get_results( $query );
	}

	/**
	 * @param $contact_id
	 * @param $note
	 * @param $note_id
	 */
	public static function update_contact_note( $contact_id, $notes, $note_id ) {

		$data = $notes;

		$where = array(
			'id'  => $note_id,
			'cid' => $contact_id,
		);

		$update_notes = self::update( $data, $where );

		return $update_notes;

	}
}