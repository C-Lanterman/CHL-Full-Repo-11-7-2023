<?php

/**
 * WC Dependency Checker
 */
class BWFAN_PRO_Plugin_Dependency {

	private static $active_plugins;

	/** checking paid membership pro is active
	 * @return bool
	 */
	public static function paid_membership_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		return in_array( 'paid-memberships-pro/paid-memberships-pro.php', self::$active_plugins, true ) || array_key_exists( 'paid-memberships-pro/paid-memberships-pro.php', self::$active_plugins );
	}

	public static function init() {
		self::$active_plugins = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() ) {
			self::$active_plugins = array_merge( self::$active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );
		}
	}

	/**
	 * check if thrive plugin active
	 * @return bool
	 */
	public static function tve_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		return in_array( 'thrive-leads/thrive-leads.php', self::$active_plugins, true ) || array_key_exists( 'thrive-leads/thrive-leads.php', self::$active_plugins );
	}

	/**
	 * Checking if learndash plugin active
	 * @return bool
	 */
	public static function learndash_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( defined( 'LEARNDASH_VERSION' ) ) {
			return true;
		}

		return in_array( 'sfwd-lms/sfwd_lms.php', self::$active_plugins, true ) || array_key_exists( 'sfwd-lms/sfwd_lms.php', self::$active_plugins );
	}

	/**
	 * Checking if ninja form plugin active
	 * @return bool
	 */
	public static function ninja_forms_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( function_exists( 'Ninja_Forms' ) ) {
			return true;
		}

		return in_array( 'ninja-forms/ninja-forms.php', self::$active_plugins, true ) || array_key_exists( 'ninja-forms/ninja-forms.php', self::$active_plugins );
	}

	/**
	 * Checking if fluent form plugin active
	 * @return bool
	 */
	public static function fluent_forms_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( defined( 'FLUENTFORM' ) ) {
			return true;
		}

		return in_array( 'fluentform/fluentform.php', self::$active_plugins, true ) || array_key_exists( 'fluentform/fluentform.php', self::$active_plugins );
	}

	/**
	 * Checking if caldera form plugin active
	 * @return bool
	 */
	public static function caldera_forms_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'Caldera_Forms' ) ) {
			return true;
		}

		return in_array( 'caldera-forms/caldera-core.php', self::$active_plugins, true ) || array_key_exists( 'caldera-forms/caldera-core.php', self::$active_plugins );
	}

	/**
	 * Checking if optim form plugin active
	 * @return bool
	 */
	public static function optin_forms_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'WFFN_Core' ) ) {
			return true;
		}

		return in_array( 'funnel-builder/funnel-builder.php', self::$active_plugins, true ) || array_key_exists( 'woofunnels-flex-funnels/woofunnels-flex-funnels.php', self::$active_plugins );
	}

	public static function wc_wishlist_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'WC_Wishlists_Plugin' ) ) {
			return true;
		}

		return in_array( 'woocommerce-wishlists/woocommerce-wishlists.php', self::$active_plugins, true ) || array_key_exists( 'woocommerce-wishlists/woocommerce-wishlists.php', self::$active_plugins );
	}

	/**
	 * Checking if weglot lanuage plugin active
	 * @return bool
	 */
	public static function weglot_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( defined( 'WEGLOT_NAME' ) ) {
			return true;
		}

		return in_array( 'weglot/weglot.php', self::$active_plugins, true ) || array_key_exists( 'weglot/weglot.php', self::$active_plugins );
	}


	/**
	 * Checking if wishlist member plugin active
	 * @return bool
	 */
	public static function wlm_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'WishListMember' ) ) {
			return true;
		}

		return in_array( 'wishlist-member-x/wpm.php', self::$active_plugins, true ) || array_key_exists( 'wishlist-member-x/wpm.php', self::$active_plugins );
	}

	/**
	 * WC Advanced shipping plugin checking
	 * @return bool
	 */
	public static function wc_advanced_shipping_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'WooCommerce_Advanced_Shipping' ) ) {
			return true;
		}

		return in_array( 'woocommerce-advanced-shipping/woocommerce-advanced-shipping.php', self::$active_plugins, true ) || array_key_exists( 'woocommerce-advanced-shipping/woocommerce-advanced-shipping.php', self::$active_plugins );
	}

	/**
	 * Advanced Coupons for woocommerce free
	 * @return bool
	 */
	public static function wc_advanced_coupons_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'ACFWF' ) ) {
			return true;
		}

		return in_array( 'advanced-coupons-for-woocommerce-free/advanced-coupons-for-woocommerce-free.php', self::$active_plugins, true ) || array_key_exists( 'advanced-coupons-for-woocommerce-free/advanced-coupons-for-woocommerce-free.php', self::$active_plugins );
	}

	public static function wc_loyalty_program_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'LPFW' ) ) {
			return true;
		}

		return in_array( 'loyalty-program-for-woocommerce/loyalty-program-for-woocommerce.php', self::$active_plugins, true ) || array_key_exists( 'loyalty-program-for-woocommerce/loyalty-program-for-woocommerce.php', self::$active_plugins );
	}

	/**
	 * WC Advanced shipping plugin checking
	 * @return bool
	 */
	public static function bwfan_is_funnel_active_check() {
		if ( ! self::$active_plugins ) {
			self::init();
		}

		if ( class_exists( 'WFFN_Core' ) ) {
			return true;
		}

		return in_array( 'funnel-builder.php', self::$active_plugins, true ) || array_key_exists( 'funnel-builder.php', self::$active_plugins );
	}
}
