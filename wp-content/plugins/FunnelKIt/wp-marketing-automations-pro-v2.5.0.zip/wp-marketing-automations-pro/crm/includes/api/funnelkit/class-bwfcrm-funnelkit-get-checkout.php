<?php

class BWFCRM_API_FunnelKit_Get_Checkout extends BWFCRM_API_Base {
	public static $ins;

	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self();
		}

		return self::$ins;
	}

	public function __construct() {
		parent::__construct();
		$this->method = WP_REST_Server::READABLE;
		$this->route  = '/funnelkit/checkouts';
	}

	public function process_api_call() {
		$ids = ! empty( $this->get_sanitized_arg( 'ids', 'text_field' ) ) ? $this->get_sanitized_arg( 'ids', 'text_field' ) : '';
		$ids = ! empty( $ids ) ? explode( ',', $ids ) : array();

		if ( ! class_exists( 'WFACP_Common' ) ) {
			$this->success_response( [] );
		}

		$data = WFACP_Common::get_saved_pages();

		if ( ! is_array( $data ) || 0 === count( $data ) ) {
			return array();
		}

		$result = array();

		foreach ( $data as $v ) {
			$result[ $v['ID'] ] = $v['post_title'] . " (#{$v['ID']})";
		}

		if ( ! empty( $ids ) ) {
			// trimming and converting ids to int value
			$ids    = array_map( 'trim', $ids );
			$ids    = array_map( 'intval', $ids );

			$result = array_filter( $result, function ( $checkout ) use ( $ids ) {
				return in_array( intval( $checkout ), $ids, true );
			}, ARRAY_FILTER_USE_KEY );
		}

		return $this->success_response( $result );
	}
}

BWFCRM_API_Loader::register( 'BWFCRM_API_FunnelKit_Get_Checkout' );
