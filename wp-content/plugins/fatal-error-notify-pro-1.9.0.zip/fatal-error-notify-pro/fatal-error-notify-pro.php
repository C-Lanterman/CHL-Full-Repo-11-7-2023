<?php

/*
Plugin Name: Fatal Error Notify Pro
Description: Receive email notifications when fatal errors occur on your WordPress site
Plugin URI: https://fatalerrornotify.com/
Version: 1.9.0
Author: Very Good Plugins
Author URI: https://verygoodplugins.com/
Text Domain: fatal-error-notify
*/

/**
 * @copyright Copyright (c) 2017. All rights reserved.
 *
 * @license   Released under the GPL license http://www.opensource.org/licenses/gpl-license.php
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * **********************************************************************
 */

// deny direct access
if ( ! function_exists( 'add_action' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit();
}

if ( ! defined( 'FATAL_ERROR_NOTIFY_VERSION' ) ) {
	define( 'FATAL_ERROR_NOTIFY_VERSION', '1.9.0' );
}

if ( ! class_exists( 'Fatal_Error_Notify' ) ) {

	final class Fatal_Error_Notify {

		/** Singleton *************************************************************/

		/**
		 * @var Fatal_Error_Notify The one true Fatal_Error_Notify
		 * @since 1.0
		 */
		private static $instance;


		/**
		 * Admin interfaces and settings
		 *
		 * @var admin
		 * @since 1.0
		 */
		public $admin;

		/**
		 * Public interface
		 *
		 * @var public
		 * @since 1.0
		 */
		public $public;

		/**
		 * Integrations
		 *
		 * @var public
		 * @since 1.5
		 */
		public $integrations;


		/**
		 * Logging interface
		 *
		 * @var logger
		 * @since 1.0
		 */
		public $logger;


		/**
		 * Are we network active?
		 *
		 * @var logger
		 * @since 1.7
		 */
		public $network_active = null;


		// Define available error levels for reporting
		public $error_levels = array(
			E_ERROR,
			E_WARNING,
			E_PARSE,
			E_NOTICE,
			E_CORE_ERROR,
			E_CORE_WARNING,
			E_COMPILE_ERROR,
			E_COMPILE_WARNING,
			E_USER_ERROR,
			E_USER_WARNING,
			E_USER_NOTICE,
			E_STRICT,
			E_RECOVERABLE_ERROR,
			E_DEPRECATED,
			E_USER_DEPRECATED,
		);


		/**
		 * Main Fatal_Error_Notify Instance
		 *
		 * Ensures that only one instance of Fatal_Error_Notify exists in memory at any one
		 * time. Also prevents needing to define globals all over the place.
		 *
		 * @since 1.0
		 *
		 * @static array $instance
		 * @return The one true Fatal_Error_Notify
		 */

		public static function instance() {

			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Fatal_Error_Notify ) ) {

				self::$instance = new Fatal_Error_Notify();
				self::$instance->setup_constants();
				self::$instance->includes();

				self::$instance->admin  = new Fatal_Error_Notify_Admin();
				self::$instance->public = new Fatal_Error_Notify_Public();
				self::$instance->logger = new Fatal_Error_Notify_Log_Handler();

				add_action( 'init', array( self::$instance, 'updater' ) );
				add_filter( 'plugin_action_links_' . FATAL_ERROR_NOTIFY_PLUGIN_PATH, array( self::$instance, 'add_action_links' ) );

				add_action( 'plugins_loaded', array( self::$instance, 'integrations_includes' ) );

				register_activation_hook( FATAL_ERROR_NOTIFY_PLUGIN_PATH, array( self::$instance, 'activate' ) );
				register_deactivation_hook( FATAL_ERROR_NOTIFY_PLUGIN_PATH, array( self::$instance, 'deactivate' ) );

			}

			return self::$instance;
		}

		/**
		 * Throw error on object clone
		 *
		 * The whole idea of the singleton design pattern is that there is a single
		 * object therefore, we don't want the object to be cloned.
		 *
		 * @access protected
		 * @return void
		 */

		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'fatal-error-notify' ), '1.0' );
		}

		/**
		 * Disable unserializing of the class
		 *
		 * @access protected
		 * @return void
		 */

		public function __wakeup() {
			// Unserializing instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'fatal-error-notify' ), '1.0' );
		}

		/**
		 * Fire on plugin activation.
		 *
		 * @since 1.8.0
		 */
		public function activate() {

			/**
			 * Copy our must-use support file(s) to the /wp-content/mu-plugins directory.
			 */

			$wpmu_plugin_dir = ( defined( 'WPMU_PLUGIN_DIR' ) && defined( 'WPMU_PLUGIN_URL' ) ) ? WPMU_PLUGIN_DIR : trailingslashit( WP_CONTENT_DIR ) . 'mu-plugins';

			if ( ! is_writable( $wpmu_plugin_dir ) ) {

				if ( ! is_dir( $wpmu_plugin_dir ) ) {
					mkdir( $wpmu_plugin_dir, 0755 );
				} else {
					chmod( $wpmu_plugin_dir, 0755 );
				}
			}

			if ( is_writable( $wpmu_plugin_dir ) ) {
				$dest_file   = trailingslashit( $wpmu_plugin_dir ) . 'fatal-error-notify-mu.php';
				$source_file = trailingslashit( FATAL_ERROR_NOTIFY_DIR_PATH ) . 'mu-plugins/fatal-error-notify-mu.php';
				copy( $source_file, $dest_file );
			}

		}

		/**
		 * Fire on plugin deactivation.
		 *
		 * @since 1.8.0
		 */
		public function deactivate() {

			/**
			 * Remove our Multisite support file(s) from the /wp-content/mu-plugins directory.
			 */
			$wpmu_plugin_dir = ( defined( 'WPMU_PLUGIN_DIR' ) && defined( 'WPMU_PLUGIN_URL' ) ) ? WPMU_PLUGIN_DIR : trailingslashit( WP_CONTENT_DIR ) . 'mu-plugins';
			if ( is_writable( $wpmu_plugin_dir ) ) {
				$dest_file = trailingslashit( $wpmu_plugin_dir ) . 'fatal-error-notify-mu.php';
				unlink( $dest_file );
			}

		}

		/**
		 * Is FEN network active?
		 *
		 * @since 1.7
		 * @return bool
		 */

		public function is_network_active() {

			if ( is_null( self::$instance->network_active ) ) {

				// If we've already done the check we don't need to do it again

				if ( is_multisite() && function_exists( 'is_plugin_active_for_network' ) && is_plugin_active_for_network( FATAL_ERROR_NOTIFY_PLUGIN_PATH ) ) {
					self::$instance->network_active = true;
				} else {
					self::$instance->network_active = false;
				}

				// We don't want to surprise anyone with the switch to network config, so if they already have settings saved on this blog, we'll let them continue to configured the plugin at the site level

				if ( true == self::$instance->network_active && ! is_network_admin() && ! empty( get_option( 'fatal_error_notify_settings' ) ) ) {
					self::$instance->network_active = false;
				}
			}

			return apply_filters( 'fen_network_active', self::$instance->network_active );

		}


		/**
		 * Setup plugin constants
		 *
		 * @access private
		 * @return void
		 */

		private function setup_constants() {

			if ( ! defined( 'FATAL_ERROR_NOTIFY_DIR_PATH' ) ) {
				define( 'FATAL_ERROR_NOTIFY_DIR_PATH', plugin_dir_path( __FILE__ ) );
			}

			if ( ! defined( 'FATAL_ERROR_NOTIFY_PLUGIN_PATH' ) ) {
				define( 'FATAL_ERROR_NOTIFY_PLUGIN_PATH', plugin_basename( __FILE__ ) );
			}

			if ( ! defined( 'FATAL_ERROR_NOTIFY_DIR_URL' ) ) {
				define( 'FATAL_ERROR_NOTIFY_DIR_URL', plugin_dir_url( __FILE__ ) );
			}

			if ( ! defined( 'FEN_STORE_URL' ) ) {
				define( 'FEN_STORE_URL', 'https://fatalerrornotify.com' );
			}

		}

		/**
		 * Include required files
		 *
		 * @access private
		 * @return void
		 */

		private function includes() {

			require_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/class-public.php';
			require_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/class-integration.php';
			require_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/save-error-log.php';
			require_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/admin/class-log-handler.php';
			require_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/admin/class-admin.php';
			require_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/admin/class-updater.php';

		}

		/**
		 * Includes plugin integrations after all plugins have loaded
		 *
		 * @access private
		 * @return void
		 */

		public function integrations_includes() {

			// Store integrations for public access
			self::$instance->integrations = new stdClass();

			// Integrations autoloader
			foreach ( self::$instance->get_integrations() as $filename => $dependency_class ) {

				if ( class_exists( $dependency_class ) ) {

					if ( file_exists( FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/integrations/class-' . $filename . '.php' ) ) {
						require_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/integrations/class-' . $filename . '.php';
					}
				}
			}

		}


		/**
		 * Defines default supported plugin integrations
		 *
		 * @access public
		 * @return array Integrations
		 */

		public function get_integrations() {

			$integrations = array(
				'gravity-forms' => 'GFForms',
				'wp-fusion'     => 'WP_Fusion',
				'woocommerce'   => 'WooCommerce',
			);

			return apply_filters( 'fen_integrations', $integrations );

		}

		/**
		 * Map error code to error string
		 *
		 * @return void
		 */

		public function map_error_code_to_type( $code ) {

			switch ( $code ) {
				case E_ERROR: // 1 //
					return 'E_ERROR';
				case E_WARNING: // 2 //
					return 'E_WARNING';
				case E_PARSE: // 4 //
					return 'E_PARSE';
				case E_NOTICE: // 8 //
					return 'E_NOTICE';
				case E_CORE_ERROR: // 16 //
					return 'E_CORE_ERROR';
				case E_CORE_WARNING: // 32 //
					return 'E_CORE_WARNING';
				case E_COMPILE_ERROR: // 64 //
					return 'E_COMPILE_ERROR';
				case E_COMPILE_WARNING: // 128 //
					return 'E_COMPILE_WARNING';
				case E_USER_ERROR: // 256 //
					return 'E_USER_ERROR';
				case E_USER_WARNING: // 512 //
					return 'E_USER_WARNING';
				case E_USER_NOTICE: // 1024 //
					return 'E_USER_NOTICE';
				case E_STRICT: // 2048 //
					return 'E_STRICT';
				case E_RECOVERABLE_ERROR: // 4096 //
					return 'E_RECOVERABLE_ERROR';
				case E_DEPRECATED: // 8192 //
					return 'E_DEPRECATED';
				case E_USER_DEPRECATED: // 16384 //
					return 'E_USER_DEPRECATED';
			}

			// Try integrations

			if ( ! empty( $this->integrations ) ) {

				foreach( $this->integrations as $integration ) {

					foreach ( $integration->get_error_types() as $slug => $label ) {

						if ( $code == $integration->slug . '_' . $slug ) {

							return $integration->title . ' ' . $label;

						}

					}

				}

			}

			return false;

		}

		/**
		 * Set up EDD updater
		 *
		 * @access public
		 * @return void
		 */

		public function updater() {

			// To support auto-updates, this needs to run during the wp_version_check cron job for privileged users.
			$doing_cron = defined( 'DOING_CRON' ) && DOING_CRON;

			if ( ! current_user_can( 'manage_options' ) && ! $doing_cron ) {
				return;
			}

			$license_key = $this->admin->get( 'license_key' );

			if ( empty( $license_key ) ) {
				$license_status = 'invalid';
			} else {
				$license_status = $this->admin->edd_check_license( $license_key );
			}

			// setup the updater
			$edd_updater = new Fatal_Error_Notify_Updater(
				FEN_STORE_URL, __FILE__, array(
					'version'   => FATAL_ERROR_NOTIFY_VERSION,
					'license'   => $license_key,
					'item_name' => 'Fatal Error Notify Pro',
					'author'    => 'Very Good Plugins',
				)
			);

			if ( 'valid' !== $license_status ) {

				global $pagenow;

				if ( 'plugins.php' === $pagenow ) {
					add_action( 'after_plugin_row_' . FATAL_ERROR_NOTIFY_PLUGIN_PATH, array( self::$instance, 'update_message' ), 1, 3 );
				}
			}

		}

		/**
		 * Display update message
		 *
		 * @access public
		 * @return mixed HTML Output
		 */

		public function update_message( $file, $plugin, $status ) {

			if ( ! current_user_can( 'update_plugins' ) || is_multisite() ) {
				return;
			}

			// Do not print any message if updates does not exist.
			$update_plugins = get_site_transient( 'update_plugins' );

			if ( ! isset( $update_plugins->response[ $file ] ) ) {
				return;
			}

			// Remove core update notice.
			remove_all_actions( "after_plugin_row_{$file}" );

			$update_notice_wrap = '<tr class="plugin-update-tr %3$s"><td colspan="4" class="plugin-update colspanchange"><div class="update-message notice inline notice-warning notice-alt invalid-license"><p>%1$s %2$s</p></div></td></tr>';
			$changelog_link     = self_admin_url( "plugin-install.php?tab=plugin-information&plugin={$plugin['slug']}&section=changelog&TB_iframe=true&width=772&height=299" );

			echo sprintf(
				$update_notice_wrap,
				sprintf(
					__( 'There is a new version of Fatal Error Notify available. %1$sView version %2$s details%3$s.', 'fatal-error-notify' ),
					'<a target="_blank" class="thickbox open-plugin-details-modal" href="' . esc_url( $changelog_link ) . '">',
					esc_html( $plugin['new_version'] ),
					'</a>'
				),
				sprintf(
					'Please <a href="%1$s" target="_blank">activate your license</a> to receive updates and support.',
					esc_url( admin_url( 'options-general.php?page=fatal-error-notify&tab=license' ) )
				),
				is_plugin_active( FATAL_ERROR_NOTIFY_PLUGIN_PATH ) ? 'active' : 'inactive'
			);

		}

		/**
		 * Add settings link to plugin page
		 *
		 * @access public
		 * @return array Links
		 */

		public function add_action_links( $links ) {

			if ( $this->is_network_active() ) {
				$url = admin_url( '/network/settings.php?page=fatal-error-notify' );
			} else {
				$url = admin_url( 'options-general.php?page=fatal-error-notify' );
			}

			$links[] = '<a href="' . $url . '">' . __( 'Settings', 'wp-fusion' ) . '</a>';

			return $links;
		}

	}

}

/**
 * The main function responsible for returning the one true Fatal Error Notify
 * Instance to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 */

if ( ! function_exists( 'fatal_error_notify' ) ) {

	function fatal_error_notify() {
		return Fatal_Error_Notify::instance();
	}

	fatal_error_notify();

}


