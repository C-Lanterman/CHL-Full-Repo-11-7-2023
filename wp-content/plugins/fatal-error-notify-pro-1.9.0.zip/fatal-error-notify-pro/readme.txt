=== Fatal Error Notify Pro ===
Contributors: verygoodplugins
Tags: error, reporting, debugging
Requires at least: 4.6
Tested up to: 6.1.1
Stable tag: 1.9.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Receive notifications whenever a fatal error occurs on your site.

== Description ==

This plugin hooks into PHP's shutdown functions to send you a notification whenever a fatal error (or other error level, configurably) is detected on your site.

Unlike traditional uptime monitoring services, which will only notify you if your entire site is down, this plugin can notify you when an error is detected on any page or process on your site.

Automatic plugin and theme updates often introduce problems that you aren't aware of until they're reported by your visitors. Fatal Error Notify lets you address these issues as they occur and before they cause significant problems.

== Installation ==

Install it just like any other WordPress plugin:

Either: Upload the plugin files to the `/wp-content/plugins/fatal-error-notify` directory.
Or: Install the plugin through the WordPress plugins screen directly.

Then:
1. Activate the plugin through the 'Plugins' screen in WordPress
2. Use the Settings->Fatal Error Notify screen to configure notification settings


== Frequently Asked Questions ==

= How does the plugin send error notifications if my site is down? =

Even the dreaded "500 - Internal Server Error" still triggers PHP's shutdown actions. Even if your site is completely offline, in most cases this plugin will be able to detect the error and notify you.

== Screenshots ==

1. Admin configuration settings
2. Example email received when an error has been reported

== Changelog ==

= 1.9.0 - 1/3/2023 =
* Added WooCommerce error notifications.

= 1.8.5 - 11/21/2022 =
* Fixed typo (misplaced parenthesis) checking `WARNING` level errors in v1.8.4
* Fixed Flush Logs button not working
* Fixed checking for the existence of the logs table on each page load
* Fixed notice `Undefined array key 1` when handling errors from a theme

= 1.8.4 - 9/9/2022 =
* Improved - Moved actions to `shutdown` action priority 1, to fix cases where other plugins generate notices or warnings during `shutdown` after a fatal error
* Improved - Out of memory errors will not be triggered multiple times within the same hour if the only part of the message that has changed is the amount of bytes
* Improved - "rmdir" warnings will be ignored by default

= 1.8.3 - 4/14/2022 =
* Fixed failed license auto-activation creating a redirect and preventing admin logins
* Fixed deactivating license not removing license key from settings
* Fixed `unlink` warnings still triggering notifications if `unlink` was the first part of the error string

= 1.8.2 - 2/15/2022 =
* Improved - If a license key is saved and the site is inactive, the site will be activated for updates on the next update check
* Improved - "unlink" warnings will be ignored by default (see https://wordpress.org/support/topic/wordfence-notification-error-wordfenceclass-php/#post-15187940)
* Fixed ampersands in the site title causing an invalid payload error with Slack notifications

= 1.8.1 - 10/4/2021 =
* Updated EDD plugin updater to v1.9.0
* Fixed error Class 'Fatal_Error_Notify_Updater' not found

= 1.8.0 - 8/26/2021 =
* Added a must-use plugin helper to allow FEN to load before all other plugins. Deactivate and re-activate FEN to install the helper file in /wp-content/mu-plugins/
* Improved - You can now trigger a manual notification by calling `fatal_error_notify()->public->send_notifications()`
* Fixed PHP notice in `Fatal_Error_Notify_Public`

= 1.7.6 - 8/5/2021 =
* Fixed Stealth Mode setting not saving

= 1.7.5 - 6/7/2021 =
* Improved - Gravity Forms notifications will now send if the note sub_type is "error"
* Fixed Slack webhooks being rejected if the site title had an apostrophe
* Fixed not being able to deactivate Stealth Mode

= 1.7.4 - 5/13/2021 =
* License key can now be defined in wp-config.php using define( 'FATAL_ERROR_NOTIFY_LICENSE_KEY', 'XXX' );
* Fixed broken pause link in email
* Fixed PHP notices in the admin

= 1.7.3 - 1/11/2021 =
* Added link to pause notifications from offending plugin
* Improved Slack message layout
* Added FEN logo to Slack notifications

= 1.7.2 - 12/16/2020 =
* Fixed PHP notice when HTTP referrer was missing
* Tested for WordPress 5.6

= 1.7.1 - 11/25/2020 =
* Fixed call to undefined function is_plugin_active_for_network()
* Fixed PHP notice when HTTP referrer was missing

= 1.7 - 10/26/2020 =
* Added ability to activate and configure the plugin at the network level
* Added fen_use_wp_mail filter
* Updated updater

= 1.6.3 - 8/30/2020 =
* Added option to un-pause paused notifications
* Added full error context to WP Fusion notifications

= 1.6.2 - 5/22/2020 =
* Fixed plugin error notifications not sending
* Fixed conflict with other plugins looking for error_log query parameter

= 1.6.1 - 1/9/2020 =
* Added ability to configure email and Slack notifications independently
* WP Fusion integration will now include the affected user ID
* Removed Auto Deactivate feature

= 1.6 - 11/30/2019 =
* Added WP Fusion API error integration
* Fixed bug with older Gravity Forms version
* Added hidden option to reset Stealth Mode

= 1.5.1 - 11/9/2019 =
* Fixed bug with undefined list_files()

= 1.5 - 10/29/2019 =
* Added framework for reporting plugin errors
* Added Gravity Forms feed error notifications
* Bugfixes for pause notification feature

= 1.4 - 9/24/2019 =
* Added link to pause notifications
* Added username of affected user to notifications
* Added setting to specify a custom From address for notification emails
* Added descriptions to common error levels

= 1.3.1 - 8/5/2019 =
* Fixed URL encoding causing invalid_payload error with Slack

= 1.3 - 4/26/2019 =
* Added request URI, HTTP Referrer, and current user ID to notifications

= 1.2 - 4/21/2018 =
* Added filter to ignore errors
* Added "Send Test" button
* Rate limiting so notifications are only sent once per hour
* Fixed link to edit file in notifications

= 1.1 - 2018/2/1 =
* Added out of memory handling

= 1.0 - 2017/12/13 =
* Initial release