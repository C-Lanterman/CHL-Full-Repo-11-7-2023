<?php

abstract class FEN_Integration {

	public $slug = '';

	public $title = '';

	/**
	 * Get things started
	 *
	 * @return void
	 */

	public function __construct() {

		fatal_error_notify()->integrations->{ $this->slug } = $this;

		$this->init();

		add_filter( 'fen_integration_error_types', array( $this, 'get_error_types' ) );

	}

	/**
	 * Initialize hooks specific to this integtation
	 *
	 * @return void
	 */

	abstract public function init();

	/**
	 * Get registered error types
	 *
	 * @return array Types
	 */

	abstract public function get_error_types();

	/**
	 * Send an error if the integration is enabled
	 *
	 * @return void
	 */

	public function handle_error( $error ) {

		$settings = fatal_error_notify()->admin->get_all();

		if ( ! empty( $settings['plugins'] ) && ! empty( $settings['plugins'][ $this->slug . '_' . $error['type'] ] ) ) {

			$error['type'] = $this->slug . '_' . $error['type'];

			fatal_error_notify()->public->send_notifications( $error );

		}

	}

}
