<?php
/* Save error log ajax function */
add_action( 'wp_ajax_save_fatal_error_log', 'save_fatal_error_log' );
function save_fatal_error_log() {
	global $wpdb,$post;
	$table_name = $wpdb->prefix . 'fatal_error_notify_log';

	$sql  = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A );
	$data = '';
	foreach ( $sql as $key => $value ) {
		if ( ! empty( $value['context'] ) ) {
			$data .= $value['context'] . "\r\n"; }
	}

	$upload_array   = wp_upload_dir();
	$error_log_path = $upload_array['basedir'] . '/fatal_error_log/';
	$filename       = $error_log_path . '' . date( 'm-d-Y' ) . '-error-log.txt';
	$file_url       = $upload_array['baseurl'] . '/fatal_error_log/' . date( 'd-m-Y' ) . '-error-log.txt';

	if ( file_exists( $filename ) ) {
		$data .= file_get_contents( $filename );
		file_put_contents( $filename, $data );
		echo 'Error log updated succesfully.';
	} else {
		if ( ! is_dir( $error_log_path ) ) {
			mkdir( $error_log_path );
			chmod( $error_log_path, 0777 ); }
		file_put_contents( $filename, $data );
		echo 'Error log generated succcessfully.';
	}
	$wpdb->query( "TRUNCATE TABLE $table_name" );
	die();
}
