<?php

/**
 * Handles log entries by writing to database.
 *
 * @class          Fatal_Error_Notify_Log_Handler
 */

class Fatal_Error_Notify_Log_Handler {

	/**
	 * Constructor for the logger.
	 */
	public function __construct() {

		add_action( 'init', array( $this, 'init' ), 100 );
		add_action( 'admin_init', array( $this, 'flush' ) );

	}

	/**
	 * Prepares logging functionalty if enabled
	 *
	 * @access public
	 * @return void
	 */

	public function init() {

		$settings = fatal_error_notify()->admin->get_all();
		if ( empty( $settings['error_log'] ) ) {
			return;
		}

		// Create the table if it hasn't been created yet.
		if ( empty( $settings['log_table_version'] ) ) {
			$this->create_update_table();
		}

	}

	/**
	 * Creates logging table if logging enabled
	 *
	 * @access public
	 * @return void
	 */

	public function create_update_table() {

		global $wpdb;
		$table_name = $wpdb->prefix . 'fatal_error_logs';

		if ( $wpdb->get_var( "show tables like '$table_name'" ) != $table_name ) {

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			$collate = '';

			if ( $wpdb->has_cap( 'collation' ) ) {
				$collate = $wpdb->get_charset_collate();
			}

			$sql = 'CREATE TABLE ' . $table_name . " (
				log_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				timestamp datetime NOT NULL,
				level smallint(5) NOT NULL,
				message longtext NOT NULL,
				plugin longtext NOT NULL,
				file longtext NOT NULL,
				PRIMARY KEY (log_id),
				KEY level (level)
			) $collate;";

			dbDelta( $sql );

		}

		fatal_error_notify()->admin->set( 'log_table_version', FATAL_ERROR_NOTIFY_VERSION );

	}

	/**
	 * Logging tab content
	 *
	 * @access public
	 * @return void
	 */

	public function show_logs_section() {

		include_once FATAL_ERROR_NOTIFY_DIR_PATH . 'includes/admin/class-log-table-list.php';

		// Flush
		if ( ! empty( $_REQUEST['flush-logs'] ) ) {
			self::flush();
		}

		// Bulk actions
		if ( isset( $_REQUEST['action'] ) && isset( $_REQUEST['log'] ) ) {
			self::log_table_bulk_actions();
		}

		$log_table_list = new Fatal_Error_Notify_Log_Table_List();
		$log_table_list->prepare_items(); ?>

		<?php $log_table_list->display(); ?>

		<?php submit_button( __( 'Flush all logs', 'fatal-error-notify' ), 'delete', 'flush-logs' ); ?>
		<?php wp_nonce_field( 'fen-logs', 'fen_logs_submit', false ); ?>

		<script type=\"text/javascript\">
			jQuery( '#flush-logs' ).on( "click", function() {
				if ( window.confirm('Are you sure you want to clear all logs from the database?' ) ) {
					return true;
				}
				return false;
			});
		</script>

		<?php

	}

	/**
	 * Handle a log entry.
	 *
	 * @param int    $timestamp Log timestamp.
	 * @param string $level emergency|alert|critical|error|warning|notice|info|debug
	 * @param string $message Log message.
	 * @param array  $context {
	 *      Additional information for log handlers.
	 *
	 *     @type string $plugin Optional. Source will be available in log table.
	 *                  If no plugin is provided, attempt to provide sensible default.
	 * }
	 *
	 * @see WPF_Log_Handler::get_log_plugin() for default plugin.
	 *
	 * @return bool False if value was not handled and true if value was handled.
	 */
	public function handle( $error ) {

		// First see if error qualifies
		$settings = fatal_error_notify()->admin->get_all();

		foreach ( $settings['levels'] as $level_id => $enabled ) {

			if ( empty( $enabled ) ) {
				continue;
			}

			if ( $error['type'] == $level_id ) {

				$timestamp = current_time( 'timestamp' );

				$file = array(
					'file' => str_replace( ABSPATH, '/', $error['file'] ),
					'line' => $error['line'],
				);

				$file_rel     = fatal_error_notify()->public->get_clean_path_from_relative_url( $error['file'] );
				$file_rel_exp = explode( '/', $file_rel );

				if ( $file_rel_exp[1] == 'plugins' ) {

					$plugin_file_rel = explode( 'plugins/', $file_rel );
					$folder_name     = explode( '/', $plugin_file_rel[1] );
					$plugin          = fatal_error_notify()->public->get_plugin_name_folder_name( $folder_name[0] );
					$plugin_data     = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin, false );
					$plugin          = $plugin_data['Title'];

				} else {
					$plugin = 'unknown';
				}

				 $this->add( $timestamp, $error['type'], $error['message'], $plugin, $file );

			}
		}

	}

	/**
	 * Add a log entry to chosen file.
	 *
	 * @param string $level emergency|alert|critical|error|warning|notice|info|debug
	 * @param string $message Log message.
	 * @param string $plugin Log plugin. Useful for filtering and sorting.
	 * @param array  $context {
	 *      Context will be serialized and stored in database.
	 *  }
	 *
	 * @return bool True if write was successful.
	 */
	protected static function add( $timestamp, $level, $message, $plugin, $file ) {
		global $wpdb;

		$insert = array(
			'timestamp' => date( 'Y-m-d H:i:s', $timestamp ),
			'level'     => $level,
			'message'   => $message,
			'plugin'    => $plugin,
			'file'      => serialize( $file ),
		);

		$format = array(
			'%s',
			'%d',
			'%s',
			'%s',
			'%s',
		);

		return false !== $wpdb->insert( "{$wpdb->prefix}fatal_error_logs", $insert, $format );
	}

	/**
	 * Clear all logs from the DB.
	 *
	 * @return bool True if flush was successful.
	 */
	public static function flush() {

		if ( ! empty( $_REQUEST['flush-logs'] ) ) { // phpcs:ignore

			if ( empty( $_REQUEST['fen_logs_submit'] ) || ! wp_verify_nonce( $_REQUEST['fen_logs_submit'], 'fen-logs' ) ) { // @codingStandardsIgnoreLine.
				wp_die( esc_html__( 'Action failed. Please refresh the page and retry.', 'wp-fusion' ) );
			}

			global $wpdb;

			$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}fatal_error_logs" );

			// Redirect to clear the URL.
			wp_safe_redirect( esc_url_raw( admin_url( 'options-general.php?page=fatal-error-notify&tab=fen_log' ) ) );
			exit;
		}

	}

	/**
	 * Bulk DB log table actions.
	 *
	 * @since 3.0.0
	 */
	private function log_table_bulk_actions() {

		if ( empty( $_REQUEST['fen_logs_submit'] ) || ! wp_verify_nonce( $_REQUEST['fen_logs_submit'], 'fen-logs' ) ) {
			wp_die( __( 'Action failed. Please refresh the page and retry.', 'fatal-error-notify' ) );
		}

		$log_ids = array_map( 'absint', (array) $_REQUEST['log'] );

		if ( 'delete' === $_REQUEST['action'] || 'delete' === $_REQUEST['action2'] ) {
			self::delete( $log_ids );
		}
	}

	/**
	 * Delete selected logs from DB.
	 *
	 * @param int|string|array Log ID or array of Log IDs to be deleted.
	 *
	 * @return bool
	 */
	public static function delete( $log_ids ) {
		global $wpdb;

		if ( ! is_array( $log_ids ) ) {
			$log_ids = array( $log_ids );
		}

		$format = array_fill( 0, count( $log_ids ), '%d' );

		$query_in = '(' . implode( ',', $format ) . ')';

		$query = $wpdb->prepare(
			"DELETE FROM {$wpdb->prefix}fatal_error_logs WHERE log_id IN {$query_in}",
			$log_ids
		);

		return $wpdb->query( $query );
	}


}
