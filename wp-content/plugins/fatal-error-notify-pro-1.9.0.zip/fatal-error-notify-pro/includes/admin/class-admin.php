<?php

class Fatal_Error_Notify_Admin {

	/**
	 * Get things started
	 *
	 * @since 1.0
	 * @return void
	 */

	public function __construct() {

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'network_admin_menu', array( $this, 'admin_menu' ) );

		add_action( 'admin_notices', array( $this, 'admin_notices' ) );
		add_action( 'wp_ajax_test_error', array( $this, 'test_error' ) );

		// Hide plugin from list
		add_action( 'pre_current_active_plugins', array( $this, 'hide_plugin' ) );

		add_action( 'admin_init', array( $this, 'maybe_activate_site' ) );
		add_filter( 'fen_get_setting_license_key', array( $this, 'get_license_key' ) );

	}

	/**
	 * Set a setting
	 *
	 * @since 1.0
	 * @return void
	 */

	public function set( $key, $val ) {

		if ( fatal_error_notify()->is_network_active() ) {
			$settings = get_site_option( 'fatal_error_notify_settings', array() );
		} else {
			$settings = get_option( 'fatal_error_notify_settings', array() );
		}

		$settings[ $key ] = $val;

		if ( fatal_error_notify()->is_network_active() ) {
			update_site_option( 'fatal_error_notify_settings', $settings );
		} else {
			update_option( 'fatal_error_notify_settings', $settings );
		}

	}

	/**
	 * Get a setting
	 *
	 * @since 1.0
	 * @return Mixed setting value
	 */

	public function get( $key, $default = false ) {

		if ( fatal_error_notify()->is_network_active() ) {
			$settings = get_site_option( 'fatal_error_notify_settings', array() );
		} else {
			$settings = get_option( 'fatal_error_notify_settings', array() );
		}

		if ( isset( $settings[ $key ] ) ) {
			return apply_filters( "fen_get_setting_{$key}", $settings[ $key ] );
		} else {
			return $default;
		}

	}

	/**
	 * Gets all settings
	 *
	 * @since 1.7
	 * @return Array Settings
	 */

	public function get_all() {

		if ( fatal_error_notify()->is_network_active() ) {
			return get_site_option( 'fatal_error_notify_settings', array() );
		} else {
			return get_option( 'fatal_error_notify_settings', array() );
		}

	}

	/**
	 * Sets all settings
	 *
	 * @since 1.7
	 * @return void
	 */

	public function set_all( $settings ) {

		if ( fatal_error_notify()->is_network_active() ) {
			update_site_option( 'fatal_error_notify_settings', $settings );
		} else {
			update_option( 'fatal_error_notify_settings', $settings );
		}

	}

	/**
	 * Maybe activate the license key if it's defined in wp-config.php
	 *
	 * @since 1.7.4
	 */
	public function maybe_activate_site() {

		if ( ( empty( $this->get( 'license_status' ) ) || 'site_inactive' == $this->get( 'license_status' ) ) && defined( 'FATAL_ERROR_NOTIFY_LICENSE_KEY' ) ) {
			$this->edd_activate( FATAL_ERROR_NOTIFY_LICENSE_KEY );
		} elseif ( ( empty( $this->get( 'license_status' ) ) || 'site_inactive' == $this->get( 'license_status' ) ) && ! empty( $this->get( 'license_key' ) ) ) {
			$this->edd_activate( $this->get( 'license_key' ) );
		}

	}

	/**
	 * Allows overriding the license key via wp-config.php
	 *
	 * @since  1.7.4
	 *
	 * @param  string|bool $license_key The license key or false.
	 * @return string|bool The license key.
	 */
	public function get_license_key( $license_key ) {

		// Allow setting license key via wp-config.php

		if ( empty( $license_key ) && defined( 'FATAL_ERROR_NOTIFY_LICENSE_KEY' ) ) {
			$license_key = FATAL_ERROR_NOTIFY_LICENSE_KEY;
		}

		return $license_key;

	}

	/**
	 * Register admin settings menu
	 *
	 * @since 1.0
	 * @return void
	 */

	public function admin_menu() {

		if ( fatal_error_notify()->is_network_active() ) {

			$id = add_submenu_page(
				'settings.php',
				'Fatal Error Notification Settings',
				'Fatal Error Notify',
				'manage_options',
				'fatal-error-notify',
				array( $this, 'settings_page' )
			);

		} else {

			// Hide page if stealth mode active
			$setting = $this->get( 'stealth_mode', array() );
			$user_id = get_current_user_id();

			if ( ! empty( $setting ) && ! in_array( $user_id, $setting ) && ! isset( $_GET['fen_bypass_stealth'] ) ) {
				return;
			}

			$id = add_submenu_page(
				'options-general.php',
				'Fatal Error Notification Settings',
				'Fatal Error Notify',
				'manage_options',
				'fatal-error-notify',
				array( $this, 'settings_page' )
			);
		}

		add_action( 'load-' . $id, array( $this, 'enqueue_scripts' ) );

	}

	/**
	 * Creates test error button
	 *
	 * @access public
	 * @return void
	 */

	public function test_error() {

		$error = array(
			'type'    => E_ERROR,
			'message' => 'Fatal Error Notify Test',
			'user'    => get_current_user_id(),
			'file'    => __FILE__,
			'line'    => 168,
		);

		fatal_error_notify()->public->send_notifications( $error );

	}

	/**
	 * Register JS and CSS files
	 *
	 * @since 1.0
	 * @return void
	 */

	public function enqueue_scripts( $hook = null ) {

		remove_all_actions( 'admin_notices' ); // don't need to see these on our page.

		// CSS
		wp_enqueue_style( 'select2', FATAL_ERROR_NOTIFY_DIR_URL . 'assets/css/select2.min.css' );
		wp_enqueue_style( 'fatal-error-notify', FATAL_ERROR_NOTIFY_DIR_URL . 'assets/css/admin.css', array(), FATAL_ERROR_NOTIFY_VERSION );

		// JS
		wp_enqueue_script( 'select2', FATAL_ERROR_NOTIFY_DIR_URL . 'assets/js/select2.full.min.js' );
		wp_enqueue_script( 'fatal-error-notify', FATAL_ERROR_NOTIFY_DIR_URL . 'assets/js/admin.js', array( 'select2', 'jquery' ), FATAL_ERROR_NOTIFY_VERSION );

		wp_localize_script( 'fatal-error-notify', 'ft_error_obj', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	}

	/**
	 * Display admin notices
	 *
	 * @since 1.0
	 * @return mixed
	 */

	public function admin_notices() {

		if ( isset( $_GET['fen_activation'] ) && ! empty( $_GET['message'] ) ) {

			switch ( $_GET['fen_activation'] ) {

				case 'false':
					$message = urldecode( $_GET['message'] );
					?>
					<div class="error">
						<p><?php echo $message; ?></p>
					</div>
					<?php
					break;

				case 'true':
				default:
					// Developers can put a custom success message here for when activation is successful if they way.
					break;

			}
		}

	}


	/**
	 * Renders Settings page
	 *
	 * @access public
	 * @return mixed
	 */

	public function settings_page() {

		// Check for license activation / deactivation
		if ( isset( $_POST['fen_license_activate'] ) ) {
			$this->edd_activate();
		} elseif ( isset( $_POST['fen_license_deactivate'] ) ) {
			$this->edd_deactivate();
		}

		// Save General Settings
		if ( isset( $_POST['fen_settings_nonce'] ) && wp_verify_nonce( $_POST['fen_settings_nonce'], 'fen_settings' ) && ! empty( $_POST['fen_settings'] ) ) {

			$settings = $this->get_all();
			$settings = array_merge( $settings, $_POST['fen_settings'] );

			// Janky way of dealing with checkboxes
			if ( isset( $_POST['checkboxes'] ) ) {
				$checkboxes = explode( ',', $_POST['checkboxes'] );

				foreach ( $checkboxes as $key ) {
					if ( ! isset( $_POST['fen_settings'][ $key ] ) ) {
						$settings[ $key ] = false;
					}
				}
			}

			// Stealth mode

			if ( 'general_data' == $_POST['fen_tab'] && ! isset( $_POST['fen_settings'] ) || ! isset( $_POST['fen_settings']['stealth_mode'] ) ) {
				$settings['stealth_mode'] = array();
			}

			$this->set_all( $settings );

			echo '<div id="message" class="updated fade"><p><strong>Settings saved.</strong></p></div>';

		}

		// Allow resetting Stealth Mode

		if ( isset( $_GET['fen_bypass_stealth'] ) ) {
			$this->set( 'stealth_mode', array() );
		}

		$tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'general_data';

		?>

		<div class="wrap">
			<h2>Fatal Error Notify Settings</h2>

			<?php $this->plugin_options_tabs(); ?>

			<?php if ( $tab == 'log' ) : ?>
				<?php $this->settings_fields( $tab ); ?>
			<?php else : ?>

				<form id="fen-settings" action="" method="post">
					
					<input type="hidden" name="action" value="update">

					<?php $this->settings_fields( $tab ); ?>

					<?php $invalid_tabs = array( 'log', 'license' ); ?>

					<?php if ( ! in_array( $tab, $invalid_tabs ) ) { ?>
						<p class="submit">
							<input name="Submit" type="submit" class="button-primary" value="Save Changes"/>
						</p>
					<?php } ?>

				</form>

			<?php endif; ?>

		</div>

		<?php
	}

	/**
	 * Register and display options tabs
	 *
	 * @since 1.0
	 * @return mixed
	 */

	public function plugin_options_tabs() {

		// Tabs
		$tabs = array(
			'general_data'         => 'General Settings',
			'notifications_email'  => 'Email Notifications',
			'notifications_slack'  => 'Slack Notifications',
			'paused_notifications' => 'Paused Notifications',
			'fen_log'              => 'Error Log',
			'license'              => 'License Key',
		);

		echo '<h1 class="nav-tab-wrapper">';

		foreach ( $tabs as $tab => $name ) {

			$current_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'general_data';

			$class = $current_tab === $tab ? 'nav-tab-active' : '';

			if ( fatal_error_notify()->is_network_active() ) {
				$url = admin_url( '/network/settings.php?page=fatal-error-notify' );
			} else {
				$url = menu_page_url( 'fatal-error-notify', 0 );
			}

			echo '<a class="nav-tab ' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '&amp;tab=' . esc_attr( $tab ) . '">' . esc_html( $name ) . '</a>';

		}

		echo '</h1>';

	}

	/**
	 * Output settings fields by tab
	 *
	 * @access public
	 * @return mixed
	 */

	public function settings_fields( $tab ) {

		$defaults = array(
			'notification_email'      => get_option( 'admin_email' ),
			'notification_email_from' => false,
			'error_log'               => false,
			'levels'                  => array(),
			'plugins'                 => array(),
			'stealth_mode'            => array(),
			'levels_slack'            => array(),
			'license_key'             => false,
			'license_status'          => 'invalid',
			'slack_notifications'     => false,
			'slack_webhook_url'       => false,
		);

		$settings = wp_parse_args( $this->get_all(), $defaults );

		// Initialize settings
		if ( empty( $settings['levels'] ) ) {

			foreach ( fatal_error_notify()->error_levels as $level_id ) {

				// Enable fatal error / parse error by default
				if ( $level_id == 1 || $level_id == 4 ) {
					$settings['levels'][ $level_id ] = true;
				} else {
					$settings['levels'][ $level_id ]       = false;
					$settings['levels_slack'][ $level_id ] = false;
				}
			}

			$this->set_all( $settings );

		} else {

			// Fill in blanks to prevent notices
			foreach ( fatal_error_notify()->error_levels as $level_id ) {

				if ( empty( $settings['levels'][ $level_id ] ) ) {
					$settings['levels'][ $level_id ] = false;
				}

				if ( empty( $settings['levels_slack'][ $level_id ] ) ) {
					$settings['levels_slack'][ $level_id ] = false;
				}
			}
		}

		wp_nonce_field( 'fen_settings', 'fen_settings_nonce' );

		echo '<input type="hidden" name="fen_tab" value="' . esc_attr( $tab ) . '" />';

		if ( $tab == 'general_data' ) {

			?>

			<h2 class="title">General Settings</h2>

			<table class="form-table">

					<input type="hidden" name="checkboxes" value="auto_deactivate,error_log" />

					<tr valign="top">
						<th scope="row"><?php _e( 'Test Crash Notification', 'fatal-error-notify' ); ?></th>
						<td>
						<a id="test-button" class="button-primary" href="#">Send Test</a>
						<p class="description">Simulates a fatal error to test email (and Slack) notifications.</p>
					</tr>


					<tr valign="top">
						<th scope="row"><?php _e( 'Plugin Errors To Notify', 'fatal-error-notify' ); ?></th>
						<td>
							<fieldset class="error-levels">

								<?php if ( empty( fatal_error_notify()->integrations ) ) : ?>

									<em>No plugin integrations found</em>

								<?php else : ?>

									<?php foreach ( fatal_error_notify()->integrations as $integration ) : ?>

										<?php foreach ( $integration->get_error_types() as $slug => $label ) : ?>

												<?php

												$id = $integration->slug . '_' . $slug;

												if ( ! isset( $settings['plugins'][ $id ] ) ) {
													$settings['plugins'][ $id ] = false;
												}

												?>

												<label for="level_<?php echo esc_attr( $id ); ?>">
													<input type="checkbox" name="fen_settings[plugins][<?php echo esc_attr( $id ); ?>]" id="level_<?php echo esc_attr( $id ); ?>" value="1" <?php checked( $settings['plugins'][ $id ] ); ?> />
													<?php echo $integration->title; ?>: <?php echo esc_html( $label ); ?>
												</label><br />

										<?php endforeach; ?>


									<?php endforeach; ?>

								<?php endif; ?>

							</fieldset>
						</td>
					</tr>

					<?php
					/*
					<tr valign="top">
						<th scope="row"><?php _e( 'Auto Deactivate', 'fatal-error-notify' ); ?></th>
						<td>
							<label for="auto_deactivate">
								<input type="checkbox" name="fen_settings[auto_deactivate]" id="auto_deactivate" <?php checked( $settings['auto_deactivate'] ); ?> value="1"  /> When this option is checked, any plugin that triggers a fatal error will automatically be deactivated.
							</label>
						</td>
					</tr>

					*/
					?>

					<tr valign="top">
						<th scope="row"><?php _e( 'Stealth Mode', 'fatal-error-notify' ); ?></th>
						<td>
							<?php
							$args = array(
								'role' => 'administrator',
							);

							$users = get_users( $args );

							if ( $users ) {

								?>
								<select id="fen-stealth-select" name="fen_settings[stealth_mode][]" multiple>
									<?php
									foreach ( $users as $user ) {

										$user_id    = $user->ID;
										$first_name = get_user_meta( $user_id, 'first_name', true );
										$last_name  = get_user_meta( $user_id, 'last_name', true );

										if ( empty( $first_name ) && empty( $last_name ) ) {
											$name = $user->display_name;
										} else {
											$name = "{$first_name} {$last_name}";
										}

										$selected = '';
										if ( ! empty( $settings['stealth_mode'] ) ) {
											$selected = in_array( $user_id, $settings['stealth_mode'] ) ? ' selected="selected" ' : '';
										}

										?>
										<option value="<?php echo $user_id; ?>" <?php echo $selected; ?> ><?php echo esc_html( $name ); ?></option>
										<?php
									}
									?>
								</select>
								<?php
							}
							?>

							<p class="description">"Stealth Mode" lets you hide Fatal Error Notify from clients, so it can't be deactivated and the settings can't be changed. Only the users selected above will be able to see the plugin.</p>

						</td>
					</tr>

					<tr valign="top">
						<th scope="row"><?php _e( 'Logging', 'fatal-error-notify' ); ?></th>
						<td>
							<label for="error_log">
								<input type="checkbox" name="fen_settings[error_log]" id="error_log" <?php checked( $settings['error_log'] ); ?> value="1"  /> Enable logging error notifications to the database.
							</label>
						</td>
					</tr>


			</table>

			<?php

		}

		// Email notifications
		if ( $tab == 'notifications_email' ) {
			?>

			<h2 class="title">Email Notifications</h2>

			
			<table class="form-table">

				<input type="hidden" name="checkboxes" value="disable_email" />

					<tr valign="top">
						<th scope="row"><?php _e( 'Notification - Email', 'fatal-error-notify' ); ?></th>
						<td>
							<input class="regular-text" type="text" name="fen_settings[notification_email]" value="<?php echo esc_attr( $settings['notification_email'] ); ?>" />
							<p class="description">Configured error notifications will be sent to this address. (Separate multiple addresses with commas)</p>
						</td>
					</tr>

					<tr valign="top">
						<th scope="row"><?php _e( 'Notification - From Email', 'fatal-error-notify' ); ?></th>
						<td>
							<input class="regular-text" type="email" name="fen_settings[notification_email_from]" value="<?php echo esc_attr( $settings['notification_email_from'] ); ?>" />
							<p class="description">Enter an authorized email address you would like the notification email sent from.</p>
						</td>
					</tr>

				<tr valign="top">
					<th scope="row"><?php _e( 'Disable Email Notifications', 'fatal-error-notify' ); ?></th>
					<td>
						<label for="disable_email">
							<input type="checkbox" name="fen_settings[disable_email]" id="disable_email" <?php checked( $settings['disable_email'] ); ?> value="1"  /> Disable email notifications.
						</label>
					</td>
				</tr>

				<tr valign="top">
					<th scope="row"><?php _e( 'PHP Error Levels To Notify via Email', 'fatal-error-notify' ); ?></th>
					<td>
						<fieldset class="error-levels">
							<?php foreach ( fatal_error_notify()->error_levels as $i => $level_id ) : ?>

								<?php $level_string = fatal_error_notify()->map_error_code_to_type( $level_id ); ?>

								<?php
								if ( empty( $settings['levels'][ $level_id ] ) ) {
									$settings['levels'][ $level_id ] = false;}
								?>

								<label for="level_<?php echo $level_string; ?>">
									<input type="checkbox" name="fen_settings[levels][<?php echo $level_id; ?>]" id="level_<?php echo $level_string; ?>" value="1" <?php checked( $settings['levels'][ $level_id ] ); ?> />
									<?php echo $level_string; ?>
								</label>

								<?php
								switch ( $level_string ) {
									case 'E_ERROR':
										echo '<span class="description"><strong>Recommended:</strong> A fatal run-time error that can\'t be recovered from.</span>';
										break;

									case 'E_WARNING':
										echo '<span class="description">Warnings indicate that something unexpected happened, but the site didn\'t crash.</span>';
										break;

									case 'E_PARSE':
										echo '<span class="description">A Parse error is uncommon but could be caused by an incomplete plugin update. Your site will be unavailable until it\'s resolved.</span>';
										break;

									case 'E_NOTICE':
										echo '<span class="description">Many plugins generate Notice-level errors, and these can usually be ignored.</span>';
										break;

									default:
										break;
								}
								?>

								<br />

							<?php endforeach; ?>
						</fieldset>

					</td>
				</tr>

			</table>

			<?php
		}

		// Slack
		if ( $tab == 'notifications_slack' ) {
			?>

		<h2 class="title">Slack Notifications</h2>

			<input type="hidden" name="checkboxes" value="slack_notification" />	
			<table class="form-table">

					<tr valign="top">
						<th scope="row"><?php _e( 'Receive Notifications via Slack', 'fatal-error-notify' ); ?></th>
						<td>
							<label for="slack_notification">
								<input type="checkbox" name="fen_settings[slack_notification]" id="slack_notification" <?php checked( $settings['slack_notification'] ); ?> value="1"  /><?php _e( 'Enable this option to receive notifications via Slack.', 'fatal-error-notify' ); ?>
							</label>
						</td>
					</tr>

					<tr valign="top">
						<th scope="row"><?php _e( 'Post to Slack Channel', 'fatal-error-notify' ); ?></th>
						<td>
							<input class="regular-text" type="text" name="fen_settings[slack_channel_id]" value="<?php echo esc_attr( $settings['slack_channel_id'] ); ?>" />
							<p class="description">Slack channel name without #</p>
						</td>
					</tr>
					<tr valign="top">
						<th scope="row"><?php _e( 'Webhook URL', 'fatal-error-notify' ); ?></th>
						<td>
							<input class="regular-text full-width" type="text" name="fen_settings[slack_webhook_url]" value="<?php echo esc_attr( $settings['slack_webhook_url'] ); ?>" />
							<p class="description"><a href="https://get.slack.help/hc/en-us/articles/115005265063-Incoming-WebHooks-for-Slack" target="_blank">Click here</a> for instructions on creating a webhook URL.</p>
						</td>
					</tr>

					<tr valign="top">
						<th scope="row"><?php _e( 'PHP Error Levels To Notify via Slack', 'fatal-error-notify' ); ?></th>
						<td>
							<fieldset class="error-levels">

								<?php

								// Set defaults
								if ( ! isset( $settings['levels_slack'] ) ) {
									$settings['levels_slack'] = $settings['levels'];
								}

								?>

								<?php foreach ( fatal_error_notify()->error_levels as $i => $level_id ) : ?>

									<?php $level_string = fatal_error_notify()->map_error_code_to_type( $level_id ); ?>

									<?php

									if ( empty( $settings['levels_slack'][ $level_id ] ) ) {
										$settings['levels_slack'][ $level_id ] = false;
									}

									?>

									<label for="level_<?php echo $level_string; ?>">
										<input type="checkbox" name="fen_settings[levels_slack][<?php echo $level_id; ?>]" id="level_<?php echo $level_string; ?>" value="1" <?php checked( $settings['levels_slack'][ $level_id ] ); ?> />
										<?php echo $level_string; ?>
									</label>

									<?php
									switch ( $level_string ) {
										case 'E_ERROR':
											echo '<span class="description"><strong>Recommended:</strong> A fatal run-time error that can\'t be recovered from.</span>';
											break;

										case 'E_WARNING':
											echo '<span class="description">Warnings indicate that something unexpected happened, but the site didn\'t crash.</span>';
											break;

										case 'E_PARSE':
											echo '<span class="description">A Parse error is uncommon but could be caused by an incomplete plugin update. Your site will be unavailable until it\'s resolved.</span>';
											break;

										case 'E_NOTICE':
											echo '<span class="description">Many plugins generate Notice-level errors, and these can usually be ignored.</span>';
											break;

										default:
											break;
									}
									?>

									<br />

								<?php endforeach; ?>
							</fieldset>

						</td>
					</tr>

			</table>

			<?php
		}

		/* Manage paused notifications */
		if ( $tab == 'paused_notifications' ) {

			if ( isset( $_GET['action'] ) ) {

				if ( ! isset( $settings['paused_notifications'] ) ) {
					$settings['paused_notifications'] = array();
				}

				if ( 'pause' == $_GET['action'] ) {

					$type = intval( $_GET['type'] );
					$file = urldecode( $_GET['file'] );
					$line = intval( $_GET['line'] );

					$hash = md5( $type . $file . $line );

					$settings['paused_notifications'][ $hash ] = array(
						'type' => $type,
						'file' => $file,
						'line' => $line,
					);

				} elseif ( 'pause_plugin' == $_GET['action'] ) {

					$hash = md5( $_GET['plugin'] );

					$settings['paused_notifications'][ $hash ] = array(
						'type' => 'all',
						'file' => sanitize_text_field( $_GET['plugin'] ),
					);

				}

				update_option( 'fatal_error_notify_settings', $settings );

				echo '<div id="message" class="updated fade"><p><strong>Notification paused.</strong></p></div>';

			}

			if ( isset( $_POST['action'] ) && 'update' == $_POST['action'] && ! empty( $_POST['un_pause'] ) ) {

				foreach ( $_POST['un_pause'] as $id ) {

					if ( isset( $settings['paused_notifications'][ $id ] ) ) {
						unset( $settings['paused_notifications'][ $id ] );
					}

					update_option( 'fatal_error_notify_settings', $settings );

				}

				echo '<div id="message" class="updated fade"><p><strong>Notification(s) un-paused.</strong></p></div>';

			}

			?>

			<h2 class="title">Paused Notifications</h2>

			<?php if ( empty( $settings['paused_notifications'] ) ) : ?>

				<p>You have no paused notifications</p>

			<?php else : ?>

				<table class="form-table">

					<tbody>

						<tr>
							<th style="width: 80px;"><?php _e( 'Un-pause?', 'fatal-error-notify' ); ?></th>
							<th style="width: 80px;"><?php _e( 'Level', 'fatal-error-notify' ); ?></th>
							<th><?php _e( 'Plugin / File', 'fatal-error-notify' ); ?></th>
							<th style="width: 80px;"><?php _e( 'Line', 'fatal-error-notify' ); ?></th>
						</tr>

						<?php foreach ( $settings['paused_notifications'] as $id => $notification ) : ?>

							<tr valign="top">

								<td>

									<input type="checkbox" name="un_pause[]" value="<?php echo $id; ?>">

								</td>

								<td>

									<?php if ( isset( $notification['type'] ) && 'all' !== $notification['type'] ) : ?>

										<?php $level = fatal_error_notify()->map_error_code_to_type( $notification['type'] ); ?>

										<span class="log-level <?php echo strtolower( $level ); ?>"><?php echo  $level; ?></span>

									<?php else : ?>

										<span class="log-level e_notice"><?php _e( 'All', 'fatal-error-notify' ); ?></span>

									<?php endif; ?>

								</td>

								<td>

									<?php echo $notification['file']; ?>

								</td>

								<td>

									<?php if ( isset( $notification['line'] ) ) : ?>

										<?php echo $notification['line']; ?>

									<?php endif; ?>

								</td>
							</tr>

						<?php endforeach; ?>

					</tbody>

				</table>

			<?php endif; ?>


			<?php
		}

		/* Export or View Error Log to Upload Folder */
		if ( $tab == 'fen_log' ) {
			?>

		<h2 class="title">Error Logs</h2>

			<?php if ( ! empty( $settings['error_log'] ) ) : ?>
				<form method="post" id="logform" action="">
					<?php fatal_error_notify()->logger->show_logs_section(); ?>
				</form>
			<?php else : ?>

				<p>You can enable the error logs from the General Settings tab</p>

			<?php endif; ?>

			<?php
		}

		if ( $tab == 'license' ) {

			if ( isset( $settings['license_status'] ) && $settings['license_status'] !== false && $settings['license_status'] == 'valid' ) {
				$active = true;
			} else {
				$active = false;
			}

			?>

			<h2 class="title">License Key</h2>

			<table class="form-table">
				<tbody>
					<tr valign="top">
						<th scope="row" valign="top">
							<?php _e( 'License Key' ); ?>
						</th>
						<td>
							<input id="license_key" 
							<?php
							if ( $active ) {
								echo 'style="border: 2px solid #46b450;"';}
							?>
							 name="fen_settings[license_key]" type="password" class="regular-text" value="<?php esc_attr_e( $settings['license_key'] ); ?>" />
							<p class="description"><?php _e( 'Enter your license key for automatic updates' ); ?></p>
						</td>
					</tr>
					<tr valign="top">
						<th scope="row" valign="top">
							<?php if ( $active ) { ?>
								<?php _e( 'Deactivate License' ); ?>
							<?php } else { ?>
								<?php _e( 'Activate License' ); ?>
							<?php } ?>
						</th>
						<td>
							<?php if ( $active ) { ?>

								<input type="submit" class="button-secondary" name="fen_license_deactivate" value="<?php _e( 'Deactivate License' ); ?>"/>

							<?php } else { ?>

								<input type="submit" class="button-secondary" name="fen_license_activate" value="<?php _e( 'Activate License' ); ?>"/>

							<?php } ?>
						</td>
					</tr>
				</tbody>
			</table>




			<?php
		}

	}

	/**
	 * Hide plugin from list in stealth mode
	 *
	 * @since 1.0
	 * @return void
	 */

	public function hide_plugin() {

		$user_id      = get_current_user_id();
		$stealth_mode = $this->get( 'stealth_mode', array() );

		if ( ! empty( $stealth_mode ) && ! in_array( $user_id, $stealth_mode ) ) {

			global $wp_list_table;

			if ( isset( $wp_list_table->items['fatal-error-notify-pro/fatal-error-notify-pro.php'] ) ) {
				unset( $wp_list_table->items['fatal-error-notify-pro/fatal-error-notify-pro.php'] );
			}
		}

	}


	/**
	 * Check EDD license
	 *
	 * @access public
	 * @return string License Status
	 */

	public function edd_check_license( $license_key ) {

		$status = get_transient( 'fen_license_check' );

		// Run the license check a maximum of once per day
		if ( false === $status ) {

			// data to send in our API request
			$api_params = array(
				'edd_action' => 'check_license',
				'license'    => $license_key,
				'item_name'  => urlencode( 'Fatal Error Notify Pro' ),
				'author'     => 'Very Good Plugins',
				'url'        => home_url(),
			);

			// Call the custom API.
			$response = wp_remote_post(
				FEN_STORE_URL, array(
					'timeout'   => 30,
					'sslverify' => false,
					'body'      => $api_params,
				)
			);

			// make sure the response came back okay
			if ( is_wp_error( $response ) ) {
				set_transient( 'fen_license_check', true, 60 * 60 * 24 * 3 );
				return 'error';
			}

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			$this->set( 'license_status', $license_data->license );

			set_transient( 'fen_license_check', true, 60 * 60 * 24 * 3 );

			return $license_data->license;

		} else {

			// Return stored license data
			return $this->get( 'license_status' );

		}

	}


	/**
	 * Activate EDD license
	 *
	 * @access public
	 * @return bool
	 */

	public function edd_activate( $license = false ) {

		// retrieve the license from post data

		if ( false == $license ) {
			$license = trim( $_POST['fen_settings']['license_key'] );
		}

		// data to send in our API request
		$api_params = array(
			'edd_action' => 'activate_license',
			'license'    => $license,
			'item_name'  => urlencode( 'Fatal Error Notify Pro' ), // the name of our product in EDD
			'url'        => home_url(),
		);

		// Call the custom API.
		$response = wp_remote_post(
			FEN_STORE_URL, array(
				'timeout'   => 15,
				'sslverify' => false,
				'body'      => $api_params,
			)
		);

		// make sure the response came back okay
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again. Code: ' ) . wp_remote_retrieve_response_code( $response );
			}
		} else {

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			if ( false === $license_data->success ) {

				switch ( $license_data->error ) {

					case 'expired':
						$message = sprintf(
							__( 'Your license key expired on %s.' ),
							date_i18n( get_option( 'date_format' ), strtotime( $license_data->expires, current_time( 'timestamp' ) ) )
						);
						break;

					case 'revoked':
						$message = __( 'Your license key has been disabled.' );
						break;

					case 'missing':
						$message = __( 'Invalid license.' );
						break;

					case 'invalid':
					case 'site_inactive':
						$message = __( 'Your license is not active for this URL.' );
						break;

					case 'item_name_mismatch':
						$message = sprintf( __( 'This appears to be an invalid license key for %s.' ), 'Fatal Error Notify Pro' );
						break;

					case 'no_activations_left':
						$message = __( 'Your license key has reached its activation limit.' );
						break;

					default:
						$message = __( 'An error occurred, please try again:' ) . '<br /><pre>' . print_r( $license_data, true ) . '</pre>';
						break;
				}
			}
		}

		// Check if anything passed on a message constituting a failure.
		if ( ! empty( $message ) && ! doing_action( 'admin_init' ) ) {

			$base_url = admin_url( 'options-general.php?page=fatal-error-notify&tab=license' );
			$redirect = add_query_arg(
				array(
					'fen_activation' => 'false',
					'message'        => urlencode( $message ),
				), $base_url
			);

			wp_safe_redirect( $redirect );
			exit();
		}

		// $license_data->license will be either "valid" or "invalid"
		$this->set( 'license_status', $license_data->license );
		$this->set( 'license_key', $license );

		if ( ! doing_action( 'admin_init' ) ) {
			wp_safe_redirect( admin_url( 'options-general.php?page=fatal-error-notify&tab=license' ) );
			exit();
		}

	}


	/**
	 * Deactivate EDD license
	 *
	 * @access public
	 * @return bool
	 */

	public function edd_deactivate() {

		// retrieve the license from the database
		$license = trim( $this->get( 'license_key' ) );

		// data to send in our API request
		$api_params = array(
			'edd_action' => 'deactivate_license',
			'license'    => $license,
			'item_name'  => urlencode( 'Fatal Error Notify Pro' ), // the name of our product in EDD
			'url'        => home_url(),
		);

		// Call the custom API.
		$response = wp_remote_post(
			FEN_STORE_URL, array(
				'timeout'   => 15,
				'sslverify' => false,
				'body'      => $api_params,
			)
		);

		// make sure the response came back okay
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {

			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again.' );
			}

			$base_url = admin_url( 'options-general.php?page=fatal-error-notify&tab=license' );
			$redirect = add_query_arg(
				array(
					'fen_activation' => 'false',
					'message'        => urlencode( $message ),
				), $base_url
			);

			wp_safe_redirect( $redirect );
			exit();
		}

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// $license_data->license will be either "deactivated" or "failed"
		if ( 'deactivated' === $license_data->license ) {
			$this->set( 'license_status', $license_data->license );
			$this->set( 'license_key', false );
		}

		wp_safe_redirect( admin_url( 'options-general.php?page=fatal-error-notify&tab=license' ) );
		exit();

	}


}
