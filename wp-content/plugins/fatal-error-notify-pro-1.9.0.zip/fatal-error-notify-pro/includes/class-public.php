<?php

class Fatal_Error_Notify_Public {

	/**
	 * Reserve some memory for shutdown
	 */

	private $memory;

	/**
	 * Get things started
	 *
	 * @return void
	 */

	public function __construct() {

		$this->memory = str_repeat( '*', 1024 * 256 );

		// 1 so it runs before any plugins potentially generate warnings during shutdown after a fatal error.
		add_action( 'shutdown', array( $this, 'shutdown' ), 1 );

	}

	/**
	 * Sends notifications for an error
	 *
	 * @return void
	 */

	public function send_notifications( $error ) {

		$settings = fatal_error_notify()->admin->get_all();

		// Send slack notification
		if ( ! empty( $settings['slack_notification'] ) && $this->is_error_type_enabled( $error, 'slack' ) ) {

			// Output of error notification
			$output = $this->get_notification_output( $error, 'slack' );

			$this->slack_notification( $output );

		}

		// Quit if not enabled for email

		if ( ! $this->is_error_type_enabled( $error, 'email' ) ) {
			return;
		}

		// Quit if no email specified or if emails are entirely disabled

		if ( empty( $settings['notification_email'] ) || empty( $settings['levels'] ) || ! empty( $settings['disable_email'] ) ) {
			return;
		}

		$output = $this->get_notification_output( $error );

		$output = '<h2>Error notification</h2>For site <a href="' . get_home_url() . '" target="_blank">' . get_home_url() . '</a><br />' . $output;

		if ( function_exists( 'wp_mail' ) && apply_filters( 'fen_use_wp_mail', true ) ) {

			add_filter( 'wp_mail_content_type', array( $this, 'wp_mail_content_type' ) );
			add_filter( 'wp_mail_from', array( $this, 'wp_mail_from' ) );

			$settings['notification_email'] = explode( ',', $settings['notification_email'] );

			foreach ( $settings['notification_email'] as $email ) {

				wp_mail( trim( $email ), 'Error notification for ' . get_home_url(), $output );

			}

		} else {

			$site_title = get_bloginfo( 'name' );
			$headers    = 'MIME-Version: 1.0' . "\r\n";
			$headers   .= 'From: ' . $site_title . ' <' . $settings['notification_email'] . '>' . "\r\n";
			$headers   .= 'Content-type:text/html;charset=UTF-8' . "\r\n";

			$settings['notification_email'] = explode( ',', $settings['notification_email'] );

			foreach ( $settings['notification_email'] as $email ) {
				mail( trim( $email ), 'Error notification for ' . get_home_url(), $output, $headers );
			}

		}

	}

	/**
	 * Get clean URL
	 *
	 * @return URL
	 */

	public function get_clean_path_from_relative_url( $path ) {

		// clean paths
		$dir_path = str_replace( '\\', '/', $path ); // file or directory
		$site_dir = trailingslashit( str_replace( '\\', '/', ABSPATH ) ); // path set in wp-config

		// remove server directory from path
		$file_rel = str_replace( $site_dir, '', $dir_path );

		return $file_rel;

	}

	/**
	 * get plugin file and folder name
	 *
	 * @return plugin file and folder name
	 */

	public function get_plugin_name_folder_name( $plugin_name ) {

		// get plugin file and folder name
		require_once ABSPATH . '/wp-admin/includes/plugin.php';
		$plugin = rtrim( $plugin_name . '/' . array_keys( get_plugins( '/' . $plugin_name ) )[0], '/' );

		return $plugin;

	}

	/**
	 * Get URL from Path for edit links
	 *
	 * @return URL
	 */

	public function get_admin_url_from_path( $path ) {

		// get clean path
		$file_rel = $this->get_clean_path_from_relative_url( $path );

		// convert to array
		$file_rel_exp = explode( '/', $file_rel );

		// get file name
		$file = end( $file_rel_exp );

		$dir_rel_url = '';

		// Themes
		if ( $file_rel_exp[2] == 'themes' ) {

			$stylesheet    = get_stylesheet();
			$theme         = wp_get_theme( $stylesheet );
			$allowed_files = $theme->get_files( 'php', 1 );

			foreach ( $allowed_files as $filename => $absolute_filename ) {
				$filename_exp     = explode( '/', $filename );
				$filename_exp_end = end( $filename_exp );
				if ( $file == $filename_exp_end ) {
					$dir_rel_url = admin_url( 'theme-editor.php?file=' . rawurlencode( $filename ) . '&amp;theme=' . rawurlencode( $stylesheet ) );
				}
			}
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		// Plugins
		if ( $file_rel_exp[2] == 'plugins' && function_exists( 'list_files' ) ) {

			// convert to array to get plugin file path
			$plugin_file_rel        = explode( 'plugins/', $file_rel );
			$get_plugin_folder_name = explode( '/', $plugin_file_rel[1] );

			// get plugin file and folder name
			$plugin       = $this->get_plugin_name_folder_name( $get_plugin_folder_name[0] );
			$plugin_files = get_plugin_files( $plugin );

			$file            = $plugin_file_rel[1];
			$plugin_file_exp = explode( '/', $file );
			$plugin_file     = end( $plugin_file_exp );

			foreach ( $plugin_files as $absolute_filename ) {
				$filename_exp     = explode( '/', $absolute_filename );
				$filename_exp_end = end( $filename_exp );
				if ( $plugin_file == $filename_exp_end ) {
					$dir_rel_url = admin_url( 'plugin-editor.php?file=' . rawurlencode( $file ) . '&amp;plugin=' . rawurlencode( $plugin ) );
				}
			}
		}

		// return
		return $dir_rel_url;

	}

	/**
	 * Send notifications with HTML formatting
	 *
	 * @return string
	 */

	public function wp_mail_content_type() {
		return 'text/html';
	}

	/**
	 * Set "From" address for notifications
	 *
	 * @return string
	 */

	public function wp_mail_from( $email ) {

		$settings = fatal_error_notify()->admin->get_all();

		if ( ! empty( $settings['notification_email_from'] ) ) {

			$email = $settings['notification_email_from'];

		}

		return $email;

	}

	/**
	 * Is error type enabled for notification
	 *
	 * @return bool
	 */

	public function is_error_type_enabled( $error, $for = false ) {

		if ( empty( $error['type'] ) ) {
			return true; // Notifications triggered programmatically always send.
		}

		$settings = fatal_error_notify()->admin->get_all();

		if ( ! empty( $settings['plugins'] ) && ! empty( $settings['plugins'][ $error['type'] ] ) ) {
			return true;
		}

		if ( 'email' === $for || false === $for || ! isset( $settings['levels_slack'] ) ) {

			if ( ! empty( $settings['levels'] ) ) {

				foreach ( $settings['levels'] as $level_id => $enabled ) {

					if ( empty( $enabled ) ) {
						continue;
					}

					if ( $error['type'] == $level_id ) {

						return true;

					}
				}

			}

		}

		if ( 'slack' === $for || false === $for ) {

			if ( ! empty( $settings['levels_slack'] ) ) {

				foreach ( $settings['levels_slack'] as $level_id => $enabled ) {

					if ( empty( $enabled ) ) {
						continue;
					}

					if ( $error['type'] == $level_id ) {

						return true;

					}
				}

			}

		}

		return false;

	}

	/**
	 * Is error paused
	 *
	 * @return bool
	 */

	public function is_error_paused( $error ) {

		$settings = fatal_error_notify()->admin->get_all();

		if ( ! empty( $settings['paused_notifications'] ) ) {

			foreach ( $settings['paused_notifications'] as $notification ) {

				if ( $notification['type'] == $error['type'] && strpos( $error['file'], $notification['file'] ) !== false && $notification['line'] == $error['line'] ) {
					return true;
				} elseif ( 'all' == $notification['type'] && false !== strpos( $error['file'], $notification['file'] ) ) {
					return true;
				}
			}
		}

		return false;

	}


	/**
	 * Catch any fatal errors and act on them
	 *
	 * @return void
	 */

	public function shutdown() {

		$this->memory = null;
		$error        = error_get_last();

		if ( is_null( $error ) ) {
			return;
		}

		// Allow bypassing.

		$ignore = apply_filters( 'fen_ignore_error', false, $error );

		if ( $ignore ) {
			return;
		}

		// A couple types of errors we don't need reported.

		if ( E_WARNING === $error['type'] && ( false !== strpos( $error['message'], 'unlink' ) || false !== strpos( $error['message'], 'rmdir' ) ) ) {
			// a lot of plugins generate these because it's faster to unlink()
			// without checking if the file exists first, even if it creates a
			// warning.
			return;
		}

		if ( ! $this->is_error_type_enabled( $error ) || $this->is_error_paused( $error ) ) {
			return;
		}

		// Rate limiting to once per hour (except for test errors).

		$message = $error['message'];

		if ( 0 === strpos( $message, 'Allowed memory' ) ) {

			// This prevents the notification being triggered for every out of
			// memory error when the only thing that's changed is the number of
			// bytes.
			//
			// @since 1.8.4.

			$message = 'Memory exhausted';
		}

		$hash      = md5( $message );
		$transient = get_transient( 'fen_' . $hash );

		if ( ! empty( $transient ) ) {
			return;
		} else {
			set_transient( 'fen_' . $hash, true, HOUR_IN_SECONDS );
		}

		$settings = fatal_error_notify()->admin->get_all();

		// Possibly log errors to database
		if ( ! empty( $settings['error_log'] ) ) {

			fatal_error_notify()->logger->handle( $error );

		}

		$this->send_notifications( $error );

	}

	/**
	 * Output of error notification
	 *
	 * @return string
	 */

	public function get_notification_output( $error, $platform = '' ) {

		// If we know the file, create the pause URLs

		if ( isset( $error['file'] ) ) {

			$error['file'] = str_replace( ABSPATH, '/', $error['file'] );

			if ( fatal_error_notify()->is_network_active() ) {
				$pause_url = admin_url( '/network/settings.php?page=fatal-error-notify&tab=paused_notifications' );
			} else {
				$pause_url = admin_url( 'options-general.php?page=fatal-error-notify&tab=paused_notifications' );
			}

			$pause_data = array(
				'action' => 'pause',
				'type'   => $error['type'],
				'file'   => $error['file'],
				'line'   => $error['line'],
			);

			$pause_url_notification = add_query_arg( $pause_data, $pause_url );

			// Pause plugin

			$plugin_file_rel        = explode( 'plugins/', $error['file'] );

			if ( isset( $plugin_file_rel[1] ) ) {
				$get_plugin_folder_name = explode( '/', $plugin_file_rel[1] );
				$plugin_name            = $get_plugin_folder_name[0];
			} else {
				$plugin_name = false;
			}

			$pause_data = array(
				'action' => 'pause_plugin',
				'plugin' => $plugin_name,
			);

			$pause_url_plugin = add_query_arg( $pause_data, $pause_url );

		}

		if ( 'slack' == $platform ) {

			// If the message has line breaks, make it a markdowncode block

			if ( strstr( $error['message'], PHP_EOL ) ) {
				$error['message'] = '```' . $error['message'] . '```';
			} else {
				$error['message'] = '`' . $error['message'] . '`';
			}

			$context = '';

			if ( isset( $error['type'] ) ) {
				$context .= '- *Error Level*: ' . fatal_error_notify()->map_error_code_to_type( $error['type'] );
			}
			$context .= "\n- *Request*: " . rawurlencode( $_SERVER['REQUEST_URI'] );
			$context .= "\n- *Referrer*: " . ( isset( $_SERVER['HTTP_REFERER'] ) ? rawurlencode( $_SERVER['HTTP_REFERER'] ) : 'unknown' );

			// The user

			if ( function_exists( 'wp_get_current_user' ) ) {

				if ( ! empty( $error['user'] ) ) {
					$user = get_user_by( 'id', $error['user'] );
				} else {
					$user = wp_get_current_user();
				}

				if ( is_object( $user ) && ! empty( $user->ID ) ) {
					$context .= "\n- *User*: <" . admin_url( 'user-edit.php?user_id=' . $user->ID ) . '|' . $user->user_login . '>';
				}
			}

			if ( isset( $error['file'] ) ) {

				// Theme or plugin URL to admin editor

				$theme_plugin_file_url = $this->get_admin_url_from_path( $error['file'] );

				if ( ! empty( $theme_plugin_file_url ) ) {
					$file = '<' . rawurlencode( $theme_plugin_file_url ) . '|' . $error['file'] . '>';
				} else {
					$file = $error['file'];
				}

				$context .= "\n- *File*: " . $file . "\n- *Line:* " . $error['line'];

			}

			$output = array(
				array(
					'type' => 'section',
					'text' => array(
						'type' => 'mrkdwn',
						'text' => '*Error notification for <' . rawurlencode( get_home_url() ) . '|' . rawurlencode( get_bloginfo( 'name' ) ) . '>*',
					),
				),
				array(
					'type'     => 'context',
					'elements' => array(
						array(
							'type' => 'mrkdwn',
							'text' => '*Message*: ' . $error['message'],
						),
					),
				),
				array(
					'type'     => 'context',
					'elements' => array(
						array(
							'type' => 'mrkdwn',
							'text' => $context,
						),
					),
				),
			);

			// Pause options

			if ( isset( $error['file'] ) ) {

				$output[] = array(
					'type'     => 'actions',
					'elements' => array(
						array(
							'type' => 'button',
							'text' => array(
								'type' => 'plain_text',
								'text' => 'Pause Notification',
							),
							'url'  => rawurlencode( $pause_url_notification ),
						),
						array(
							'type' => 'button',
							'text' => array(
								'type' => 'plain_text',
								'text' => 'Mute Plugin',
							),
							'url'  => rawurlencode( $pause_url_plugin ),
						),
					),
				);

			}

		} else {

			$output = '<ul>';

			if ( isset( $error['type'] ) ) {
				$output .= '<li><strong>Error Level:</strong> ' . fatal_error_notify()->map_error_code_to_type( $error['type'] ) . '</li>';
			}

			$output .= '<li><strong>Message:</strong> ' . nl2br( $error['message'] ) . '</li>';

			if ( isset( $error['file'] ) ) {

				// Theme or plugin URL to Admin Editor
				$theme_plugin_file_url = $this->get_admin_url_from_path( $error['file'] );

				if ( ! empty( $theme_plugin_file_url ) ) {
					$output .= '<li><strong>File:</strong><a href="' . $theme_plugin_file_url . '"> ' . $error['file'] . '</a></li>';
				} else {
					$output .= '<li><strong>File:</strong> ' . $error['file'] . '</li>';
				}

				$output .= '<li><strong>Line:</strong> ' . $error['line'] . '</li>';

			}

			if ( isset( $_SERVER['HTTP_REFERER'] ) ) {
				$referrer = $_SERVER['HTTP_REFERER'];
			} else {
				$referrer = 'unknown';
			}

			$output .= '<li><strong>Request:</strong> ' . $_SERVER['REQUEST_URI'] . '</li>';
			$output .= '<li><strong>Referrer:</strong> ' . $referrer . '</li>';

			if ( function_exists( 'wp_get_current_user' ) ) {

				$user = wp_get_current_user();

				if ( ! empty( $user ) ) {
					$output .= '<li><strong>User:</strong> <a href="' . admin_url( 'user-edit.php?user_id=' . $user->ID ) . '">' . $user->user_login . '</a></li>';
				}

			}

			$output .= '</ul><br />';

			if ( isset( $error['file'] ) ) {

				$output .= '<a href="' . $pause_url_notification . '">Pause This Notification</a>';

			}

		}

		return $output;

	}

	/**
	 * Send Notification to Slack
	 *
	 * @return void
	 */

	public function slack_notification( $notification = '' ) {

		$settings    = fatal_error_notify()->admin->get_all();
		$channel_id  = $settings['slack_channel_id'];

		$attachment = array(
			'fallback' => 'Error notification for ' . rawurlencode( get_bloginfo( 'name' ) ), // A required markdown textfield that is displayed on devices that can't display Attachments
			'color'    => 'danger', // Can either be one of 'good', 'warning', 'danger', or any hex color code, but this is Pantheon Yellow
			'text'     => $notification,
		);

		$data = 'payload=' . json_encode(
			array(
				'channel'  => "#{$channel_id}",
				'text'     => 'Error notification for <' . rawurlencode( get_home_url() ) . '|' . rawurlencode( get_bloginfo( 'name' ) ) . '>',
				'icon_url' => 'https://fatalerrornotify.com/wp-content/themes/fatal-error-notify-theme/logo-color.png',
				'username' => rawurlencode( get_bloginfo( 'name' ) ),
				'blocks'   => $notification,
			)
		);

		$data = str_replace( '&#039;', '', $data );

		$params = array(
			'body'     => $data,
			'blocking' => false,
		);

		wp_remote_post( $settings['slack_webhook_url'], $params );

	}

}
