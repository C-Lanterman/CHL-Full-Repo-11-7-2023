<?php

/**
 * Handles WooCommerce errors.
 *
 * @since 1.9.0
 *
 * @class FEN_WooCommerce
 */
class FEN_WooCommerce extends FEN_Integration {

	/**
	 * Slug.
	 *
	 * @since 1.9.0
	 *
	 * @var string
	 */
	public $slug = 'woocommerce';

	/**
	 * Title.
	 *
	 * @since 1.9.0
	 *
	 * @var string
	 */
	public $title = 'WooCommerce';

	/**
	 * Get registered error types.
	 *
	 * @since 1.9.0
	 *
	 * @return array Types
	 */
	public function get_error_types() {

		$types = array(
			'emergency' => __( 'System is unusable.', 'fatal-error-notify' ),
			'alert'     => __( 'Action must be taken immediately.', 'fatal-error-notify' ),
			'critical'  => __( 'Critical conditions.', 'fatal-error-notify' ),
			'error'     => __( 'Error conditions.', 'fatal-error-notify' ),
			'warning'   => __( 'Warning conditions.', 'fatal-error-notify' ),
			'notice'    => __( 'Normal but significant condition.', 'fatal-error-notify' ),
			'info'      => __( 'Informational messages.', 'fatal-error-notify' ),
			'debug'     => __( 'Debug-level messages.', 'fatal-error-notify' ),
		);

		return $types;

	}

	/**
	 * Get things started.
	 *
	 * @since 1.9.0
	 */
	public function init() {

		add_filter( 'woocommerce_logger_log_message', array( $this, 'log_message' ), 10, 3 );

	}

	/**
	 * Report error
	 *
	 * @since 1.9.0
	 *
	 * @param string $message The message.
	 * @param string $level   The level.
	 * @param array  $context The context.
	 * @return string The message.
	 */
	public function log_message( $message, $level, $context ) {

		$error = array(
			'type'    => $level,
			'message' => $message,
			'user'    => get_current_user_id(),
		);

		$this->handle_error( $error );

		return $message;

	}

}

new FEN_WooCommerce();
