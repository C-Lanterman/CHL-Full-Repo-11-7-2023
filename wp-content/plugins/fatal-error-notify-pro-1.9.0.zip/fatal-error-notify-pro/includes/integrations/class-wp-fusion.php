<?php

class FEN_WP_Fusion extends FEN_Integration {

	public $slug = 'wp-fusion';

	public $title = 'WP Fusion';

	/**
	 * Get registered error types
	 *
	 * @return array Types
	 */

	public function get_error_types() {

		$types = array(
			'api_error' => 'API error',
		);

		return $types;

	}

	/**
	 * Get things started
	 *
	 * @return void
	 */

	public function init() {

		add_action( 'wpf_handle_log', array( $this, 'handle_log' ), 10, 5 );

	}

	/**
	 * Report error
	 *
	 * @return void
	 */

	public function handle_log( $timestamp, $level, $user, $message, $context ) {

		if ( 'error' !== $level ) {
			return;
		}

		$error = array(
			'type'    => 'api_error',
			'message' => 'WP Fusion API error for user #' . $user . ': ' . strip_tags( $message ),
			'user'    => $user,
		);

		if ( ! empty( $context ) ) {
			$error['message'] .= "\n\n" . print_r( $context, true );
		}

		$this->handle_error( $error );

	}

}

new FEN_WP_Fusion();
