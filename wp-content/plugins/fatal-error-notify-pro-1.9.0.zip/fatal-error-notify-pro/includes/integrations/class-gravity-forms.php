<?php

class FEN_Gravity_Forms extends FEN_Integration {

	public $slug = 'gravity-forms';

	public $title = 'Gravity Forms';

	/**
	 * Get registered error types
	 *
	 * @return array Types
	 */

	public function get_error_types() {

		$types = array(
			'feed_error' => 'Feed error',
		);

		return $types;

	}

	/**
	 * Get things started
	 *
	 * @return void
	 */

	public function init() {

		add_action( 'gform_post_note_added', array( $this, 'post_note_added' ), 10, 7 );

	}

	/**
	 * Report error
	 *
	 * @return void
	 */

	public function post_note_added( $note_id, $entry_id, $user_id, $user_name, $note, $note_type, $sub_type = false ) {

		if ( 'error' !== $note_type && 'error' !== $sub_type ) {
			return;
		}

		$entry = GFAPI::get_entry( $entry_id );
		$form = GFAPI::get_form( $entry['form_id'] );

		$error = array(
			'type'    => 'feed_error',
			'message' => 'Form "' . $form['title'] . '". Entry ID ' . $entry_id . '. ' . $note,
			'user'    => $user_id,
		);

		$this->handle_error( $error );

	}

}

new FEN_Gravity_Forms;
