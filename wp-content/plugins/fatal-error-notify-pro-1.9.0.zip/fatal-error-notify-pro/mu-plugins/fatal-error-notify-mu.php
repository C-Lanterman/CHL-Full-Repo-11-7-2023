<?php
/**
 * Plugin Name: Fatal Error Notify Pro Loader
 * Plugin URI: https://fatalerrornotify.com/
 * Description: Ensures that Fatal Error Notify loads before all other plugins.
 * Version: 1.0.0
 * Author: Very Good Plugins
 * Author URI: https://verygoodplugins.com/
 * Text Domain: fatal-error-notify
 *
 * @since 1.8.0
 *
 * @package Fatal Error Notify Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	die();
}

$file = WP_PLUGIN_DIR . '/fatal-error-notify-pro/fatal-error-notify-pro.php';

if ( file_exists( $file ) ) {
	require_once $file;
}
