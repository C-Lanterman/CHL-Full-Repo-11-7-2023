# Contributing Guide

Please follow these steps to start contributing:

1. Clone the repo.

    `git clone git@github.com:stellarwp/learndash-groups-plus.git`

2. Install composer dependencies.

    `composer install`

3. Install npm dependencies.

    `npm install`

4. Run watch script to generate necessary build assets while working on the code.

    `npm run start`



## Generating release-ready zip package

Release-ready zip package is plugin zip file that can be uploaded and activated directly on WordPress install.

Plese follow these steps to generate the zip package:

1. Make sure you're on the right git branch.

    `git status`

2. Run the build script.

    `composer run build`

3. The zip package file will be available on the project root folder.