<?php
namespace LearnDash\Groups_Plus\Module;

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Module interface.
 * 
 * @since 1.1.0
 */
interface Module_Interface {

}
