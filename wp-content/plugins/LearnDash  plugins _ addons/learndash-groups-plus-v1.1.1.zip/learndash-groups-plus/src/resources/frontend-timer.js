/***
 * Timer script.
 */

// Dependencies.
import 'jquery'; /* eslint-disable-line import/no-unresolved */

// Script
import './js/timer.js';
