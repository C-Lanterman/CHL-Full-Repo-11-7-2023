/**
 * Entry point of wp-scripts build for admin stuff.
 */
// Dependencies.
import 'jquery';

// CSS.
import './css/admin.scss';

// Javascript.
import './js/admin-post.js';
import './js/admin-profile.js';
