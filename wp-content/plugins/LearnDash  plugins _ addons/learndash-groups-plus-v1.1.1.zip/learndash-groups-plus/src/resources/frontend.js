/**
 * Entry point of wp-scripts build for frontend stuff.
 */

/* eslint-disable import/no-unresolved */
// Dependencies.
import 'jquery';
import 'learndash-groups-plus-pair-select';
import 'learndash-groups-plus-sweet-alert';
import 'learndash-groups-plus-jquery-validate';
import 'learndash-groups-plus-select2';
import 'learndash-groups-plus-font-awesome';
/* eslint-enable import/no-unresolved */

// CSS.
import './css/grid.css';
import './css/frontend.scss';

// Javascript.
import './js/groups-plus-report.js';
import './js/groups-plus.js';
import './js/team-member.js';
