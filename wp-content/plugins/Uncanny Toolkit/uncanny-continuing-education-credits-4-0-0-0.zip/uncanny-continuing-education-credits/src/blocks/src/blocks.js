/**
 * Gutenberg Blocks
 *
 * All blocks related JavaScript files should be imported here.
 * You can create a new block folder in this dir and include code
 * for that block here as well.
 *
 * All blocks should be included here since this is the file that
 * Webpack is compiling as the input file.
 */

import './ceu-available-credits/block.js';
import './ceu-certificate-trigger-description/block.js';
import './ceu-credits-remaining/block.js';
import './ceu-earned-credits/block.js';
import './ceu-course-report/block.js';
import './ceu-total-credits/block.js';
import './ceu-total-days-remaining/block.js';
import './ceu-total-rollover-credits/block.js';