<?php

namespace uncanny_ceu;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Class CeusColumnUoProTranscript
 * @package uncanny_ceu
 */
class CeusColumnUoProTranscript {

	/**
	 * class constructor
	 *
	 */
	function __construct() {
		add_filter( 'uo_pro_transcript', array( $this, 'uo_filter_transcript_table' ), 10, 3 );
		add_filter( 'uo_pro_transcript_cumulative_column', array(
			$this,
			'uo_pro_transcript_cumulative_column'
		), 10, 3 );
	}

	/**
	 * Add CEUs headling to UO Transcript
	 *
	 * @param $table
	 *
	 * @return mixed
	 */

	/**
	 * Add CEUs headling and row values to UO Transcript
	 *
	 * @param $transcript
	 * @param $current_user
	 * @param $learndash_transcript
	 *
	 * @return mixed
	 */
	public function uo_filter_transcript_table( $transcript, $current_user, $learndash_transcript ) {

		if ( 'on' !== $learndash_transcript::get_settings_value( 'uncanny-disable-ceus-col', $learndash_transcript ) ) {

			$credit_designation_label_plural = Utilities::credit_designation_label( 'plural', __( 'CEUs', 'uncanny-ceu' ) );
			$transcript->table->heading->ceu = $credit_designation_label_plural;

			global $wpdb;

			$q           = "Select meta_key, meta_value FROM $wpdb->usermeta WHERE meta_key LIKE 'ceu_earned_%' AND user_id = $current_user->ID";
			$completions = $wpdb->get_results( $q, ARRAY_A );

			$ceu_complettions = array();
			foreach ( $completions as $completion ) {
				$course_id                      = explode( '_', $completion['meta_key'] );
				$course_id                      = $course_id[3];
				$ceu_complettions[ $course_id ] = $completion['meta_value'];
			}

			$credit_designation_label_plural = Utilities::credit_designation_label( 'plural', __( 'CEUs', 'uncanny-ceu' ) );
			$table['headings'][]             = $credit_designation_label_plural;
			$total_ceus                      = 0;

			foreach ( $transcript->table->rows as $course_id => &$row ) {

				$ceus = __( '0', 'uncanny-ceu' );
				if ( isset( $ceu_complettions[ $course_id ] ) ) {
					$ceus = $ceu_complettions[ $course_id ];
				}
				$total_ceus += $ceus;
				$row->ceu   = $ceus;
			}

			// Show CEUs in transcript
			if ( 'on' === $learndash_transcript::get_settings_value( 'uncanny-enable-ceus-rows', $learndash_transcript ) ) {
				
				// Get the first row element's key
				$first_key = key( $transcript->table->rows );
				if ( ! empty( $first_key ) ) {
					// Turn the first element into an array
					$array = get_object_vars( $transcript->table->rows[ $first_key ] );
					// User the first element array to get all the object properties
					$properties = array_keys( $array );
				} else {
					$properties = array_keys( get_object_vars( $transcript->table->heading ) );
				}

				$ceu_completions = array();

				$user_meta = get_user_meta( $current_user->ID );

				foreach ( $user_meta as $meta_key => $meta_value ) {

					if ( false !== strpos( $meta_key, 'ceu_' ) ) {

						$key        = explode( '_', $meta_key );
						$collection = array( 'title', 'date', 'course', 'earned' );

						if ( ! in_array( $key[1], $collection ) ) {
							continue;
						}

						$unique_key = $key[2] . '_' . $key[3] . '_' . $current_user->ID; //unique identifier for ceu completion...  {timestamp}_{course ID}
						$value_key  = $key[0] . '_' . $key[1]; // name of data stored... ceu_title  ceu_date  ceu_course  ceu_earned

						if ( 'ceu_earned' === $value_key ) {
							$total_ceus += (float) $meta_value[0];
						}

						if ( ! isset( $ceu_completions[ $unique_key ] ) ) {
							$ceu_completions[ $unique_key ]              = array();
							$ceu_completions[ $unique_key ]['course_id'] = $key[3];
							$ceu_completions[ $unique_key ]['course']    = $key[3];
							$ceu_completions[ $unique_key ]['total']     = 0;
						}

						$ceu_completions[ $unique_key ][ $value_key ] = $meta_value[0];

						if ( 'ceu_earned' === $value_key ) {
							$ceu_completions[ $unique_key ]['total'] += $total_ceus;
						}
					}
				}

				foreach ( $ceu_completions as $key => $completion ) {

					if ( 'manual-ceu' !== $completion['ceu_course'] ) {
						continue;
					}

					// Create an object with all the expected keys with empty values
					$_row = (object) [];
					foreach ( $properties as $property ) {
						$_row->$property = '';
					}

					// Add row data
					$_row->course_title  = $completion['ceu_title'];
					$_row->course_date   = $completion['ceu_date'];
					$_row->course_status = esc_html__( 'Completed', 'learndash' );;
					$_row->ceu = (float) $completion['ceu_earned'];

					// add created row to the transcript
					$transcript->table->rows[ $key ] = $_row;

					// Increment the CEU value total
					$total_ceus += $_row->ceu;

					// add courses completed to summary
					if( isset($transcript->summary->status_completed) ){
						$transcript->summary->status_completed ++;
					}
					if( isset($transcript->summary->status_enrolled) ) {
						$transcript->summary->status_enrolled ++;
					}
				}
			}

			// re-set the total CEUs footer column
			$transcript->final_ceus = $total_ceus;

			if( isset($transcript->summary->status_completed) && isset($transcript->summary->status_enrolled)){
				// re-set the total courses completed header summary column
				$transcript->summary->status = sprintf(
					esc_attr__( '%1$s / %2$s courses completed', 'uncanny-ceu' ),
					$transcript->summary->status_completed,
					$transcript->summary->status_enrolled
				);
			}
		}

		return $transcript;
	}

	/**
	 * Add cumulative value for the CEU column
	 *
	 * @param $column
	 * @param $key
	 * @param $transcript
	 *
	 * @return array
	 */
	public function uo_pro_transcript_cumulative_column( $column, $key, $transcript ) {

		if ( 'ceu' === $key ) {
			$total_ceus = 0;
			foreach ( $transcript->table->rows as $course_id => $row ) {
				if ( isset( $row->ceu ) ) {
					$total_ceus += $row->ceu;
				}
			}

			$credit_designation_label_plural = Utilities::credit_designation_label( 'plural', __( 'CEUs', 'uncanny-ceu' ) );

			$title = sprintf(
			// Translators: %1$s credit designation label plural
				__( 'Total %1$s Earned', 'uncanny-ceu' ),
				$credit_designation_label_plural
			);

			$column[ $key ]['title'] = $title;
			$column[ $key ]['value'] = $total_ceus;

			return $column;
		};

		return $column;
	}
}
