<?php

namespace uncanny_ceu;

/**
 *
 */
class CeuArchivedQuizResults {

	/**
	 *
	 */
	public function __construct() {

		//Add Additional field on User Settings page for Archived quiz results.
		$pr = 10;
		add_action(
			'show_user_profile',
			array(
				$this,
				'add_additional_quiz_fields',
			),
			$pr
		);
		add_action(
			'edit_user_profile',
			array(
				$this,
				'add_additional_quiz_fields',
			),
			$pr
		);

	}

	/**
	 * Displays users course information at bottom of profile
	 * called by show_user_profile().
	 *
	 * @param WP_User $user wp user object.
	 */
	public function add_additional_quiz_fields( $user ) {
		$user_id     = $user->ID;
		$all_quizzes = $this->get_quizzes( $user_id );

		if ( empty( $all_quizzes ) || count( $all_quizzes ) === 0 ) {
			return;
		}

		echo '<h3 style="margin-top:30px;">' . esc_html__( 'Archived quiz results:', 'uncanny-ceu' ) . '</h3>';

		$final_list = array();
		foreach ( $all_quizzes as $quiz ) :
			$matched_record = $this->match_quiz( $user_id, $quiz['course_id'], $quiz['quiz_id'], $quiz['date_completed'] );
			if ( false === $matched_record ) {
				$final_list[] = $quiz;
			}
		endforeach;

		if ( is_array( $final_list ) && count( $final_list ) > 0 ) {
			echo '<div class="ceu-archived-quiz-content-container">';
			foreach ( $final_list as $quiz ) :
				if ( is_array( $quiz ) ) {
					$count_init = 0;
					if ( 0 !== (int) $quiz['score'] && 0 !== (int) $quiz['count'] ) {
						$count_init = $quiz['score'] / $quiz['count'];
					}
					$css       = (int) $quiz['passed'] ? 'green' : 'red';
					$count_fin = $count_init * 100;
					echo '<p id="ceu-quiz">';
					echo '<strong><a href="' . get_permalink( $quiz['quiz_id'] ) . '">' . get_the_title( $quiz['quiz_id'] ) . '</a></strong> - ';
					echo '<span style="color:' . $css . '">' . number_format( $count_fin, 2 ) . '%</span><br>';
					echo sprintf( __( 'Score %1$s out of %2$s question(s) . Points: %3$s on %4$s', 'uncanny-ceu' ), $quiz['score'], $quiz['count'], $quiz['score'] . '/' . $quiz['count'], get_date_from_gmt( date( 'Y-m-d H:i:s', $quiz['date_completed'] ), 'F d, Y h:i:s a' ) );
					echo '</p>';
				}
			endforeach;
			echo '</div>';
		}
	}

	/**
	 * @param $user_id
	 *
	 * @return void
	 */
	public function get_quizzes( $user_id ) {
		global $wpdb;
		$table_name  = $wpdb->prefix . 'uo_ceu_historical_quiz_data';
		$query       = "SELECT * FROM {$table_name} WHERE `user_id` = %d";
		$all_quizzes = $wpdb->get_results( $wpdb->prepare( $query, $user_id ), ARRAY_A );

		return is_array( $all_quizzes ) ? $all_quizzes : array();
	}


	/**
	 * @param $user_id
	 * @param $course_id
	 * @param $quiz_id
	 * @param $date_completed
	 *
	 * @return array
	 */
	public function match_quiz( $user_id, $course_id, $quiz_id, $date_completed ) {
		global $wpdb;
		$table_name      = $wpdb->prefix . 'learndash_user_activity';
		$query           = "SELECT * FROM {$table_name} WHERE `user_id` = %d AND `course_id` = %d AND `post_id` = %d AND `activity_completed` = %s";
		$matched_quizzes = $wpdb->get_results( $wpdb->prepare( $query, $user_id, $course_id, $quiz_id, $date_completed ), ARRAY_A );

		return ( count( $matched_quizzes ) > 0 ) ? true : false;
	}

}
