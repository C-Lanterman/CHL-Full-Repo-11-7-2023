<?php

namespace uncanny_ceu;

/**
 * Class CeuMigrateUserRecords
 */
class CeuMigrateUserRecords {

	/**
	 * @var mixed|void
	 */
	public static $initial_move;


	/**
	 *
	 */
	public function __construct() {
		self::$initial_move = get_option( 'uo-has-ld-data-not-moved-to-archive', true );
		add_filter( 'cron_schedules', array( $this, 'ceu_cron_schedules' ) );
		add_action( 'uo_ceu_archive_course', array( $this, 'run_course_archive' ) );
		add_action( 'uo_ceu_archive_quiz', array( $this, 'run_quiz_archive' ) );
	}

	/**
	 *
	 */
	public function run_quiz_archive( $start = 0, $end = 500 ) {
		global $wpdb;
		$history_quiz_data = $wpdb->prefix . 'uo_ceu_historical_quiz_data';
		$get_user_data     = $wpdb->get_results( $wpdb->prepare( "SELECT *
FROM {$wpdb->usermeta}
WHERE meta_key LIKE '_sfwd-quizzes'
ORDER BY user_id ASC
LIMIT %d, %d", $start, $end ) );

		if ( empty( $get_user_data ) ) {
			wp_clear_scheduled_hook( 'uo_ceu_archive_quiz' );

			return;
		}

		foreach ( $get_user_data as $data ) {
			$user_id    = $data->user_id;
			$meta_key   = $data->meta_key;
			$meta_value = maybe_unserialize( $data->meta_value );
			if ( is_array( $meta_value ) && ! empty( $meta_key ) ) {
				foreach ( $meta_value as $quiz_data ) {
					$quiz             = $quiz_data['quiz'];
					$statistic_ref_id = $quiz_data['statistic_ref_id'];
					$course           = $quiz_data['course'];
					$lesson           = $quiz_data['lesson'];
					$topic            = $quiz_data['topic'];
					$pass             = $quiz_data['pass'];
					$score            = $quiz_data['score'];
					$count            = $quiz_data['count'];
					$time             = $quiz_data['time'];
					$store            = $quiz_data;
					$since            = ld_course_access_from( is_object( $course ) ? $course->ID : $course, $user_id );
					if ( empty( $since ) ) {
						$since = learndash_user_group_enrolled_to_course_from( $user_id, is_object( $course ) ? $course->ID : $course );
					}

					if ( isset( $store['quiz'] ) ) {
						unset( $store['quiz'] );
					}
					if ( isset( $store['course'] ) ) {
						unset( $store['course'] );
					}
					if ( isset( $store['lesson'] ) ) {
						unset( $store['lesson'] );
					}
					if ( isset( $store['topic'] ) ) {
						unset( $store['topic'] );
					}
					if ( isset( $store['questions'] ) ) {
						unset( $store['questions'] );
					}
					$insert = array(
						'user_id'          => $user_id,
						'statistic_ref_id' => $statistic_ref_id,
						'course_id'        => is_object( $course ) ? $course->ID : $course,
						'lesson_id'        => is_object( $lesson ) ? $lesson->ID : $lesson,
						'topic_id'         => is_object( $topic ) ? $topic->ID : $topic,
						'quiz_id'          => is_object( $quiz ) ? $quiz->ID : $quiz,
						'passed'           => $pass,
						'score'            => $score,
						'count'            => $count,
						'data'             => maybe_serialize( $store ),
						'certificate'      => '',
						'date_completed'   => $time,
						'date_enrolled'    => $since,
					);
					$flag   = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$history_quiz_data} WHERE `date_completed` = '%s' AND `user_id` = %d", $time, $user_id ) );
					if ( $flag > 0 ) {
						continue;
					}
					$wpdb->insert(
						$history_quiz_data,
						$insert,
						array(
							'%d',
							'%d',
							'%d',
							'%d',
							'%d',
							'%d',
							'%s',
							'%s',
							'%s',
							'%s',
							'%s',
							'%s',
						)
					);
					CeuStoreHistoricalData::copy_stat_records( $statistic_ref_id );
					do_action( 'uo_ceu_historical_quiz_recorded', $insert );

				}
			}
		}

		update_option( 'uo-ceu-quize-archived', date( 'Y-m-d H:i', current_time( 'timestamp' ) ) );
		$next = $start + $end;
		wp_schedule_single_event( time() + 60, 'uo_ceu_archive_quiz', array( $next, $end ) );
	}

	/**
	 *
	 */
	public function run_course_archive( $start = 0, $end = 500 ) {
		global $wpdb;
		$history_courses_data = $wpdb->prefix . 'uo_ceu_historical_course_data';
		$get_user_data        = $wpdb->get_results( $wpdb->prepare( "SELECT *
FROM {$wpdb->usermeta}
WHERE meta_key NOT LIKE '_sfwd-quizzes'
ORDER BY user_id ASC
LIMIT %d, %d", $start, $end ) );

		if ( empty( $get_user_data ) ) {
			wp_clear_scheduled_hook( 'uo_ceu_archive_course' );

			return;
		}

		$user_ids        = array_column( $get_user_data, 'user_id' );
		$course_progress = $this->normalize_course_data( $get_user_data );

		if ( empty( $course_progress ) ) {
			wp_clear_scheduled_hook( 'uo_ceu_archive_course' );

			return;
		}

		foreach ( $user_ids as $user_id ) {
			$courses = $course_progress[ $user_id ];
			if ( is_array( $courses ) ) {
				foreach ( $courses as $course_id => $c_p ) {
					$since = isset( $c_p['access_from'] ) ? $c_p['access_from'] : '';
					if ( empty( $since ) ) {
						$since = ld_course_access_from( $course_id, $user_id );
						if ( empty( $since ) ) {
							$since = learndash_user_group_enrolled_to_course_from( $user_id, $course_id );
						}
					}
					if ( ! array_key_exists( 'completed', $c_p ) ) {
						continue;
					}
					$flag = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$history_courses_data} WHERE `date_completed` = '%s' AND `user_id` = %d", $c_p['completed'], $user_id ) );
					if ( $flag > 0 ) {
						continue;
					}
					$counter ++;
					$insert = array(
						'user_id'        => $user_id,
						'course_id'      => $course_id,
						'progress'       => isset( $c_p['progress'] ) ? $c_p['progress'] : '',
						'certificate'    => isset( $c_p['cert'] ) ? $c_p['cert'] : '',
						'date_enrolled'  => $since,
						'date_completed' => isset( $c_p['completed'] ) ? $c_p['completed'] : '',
					);
					$wpdb->insert(
						$history_courses_data,
						$insert,
						array(
							'%d',
							'%d',
							'%s',
							'%s',
							'%s',
							'%s',
						)
					);
					do_action( 'uo_ceu_historical_course_recorded', $insert );
				}
			}
		}

		update_option( 'uo-ceu-course-archived', date( 'Y-m-d H:i', current_time( 'timestamp' ) ) );
		$next = $start + $end;
		wp_schedule_single_event( time() + 60, 'uo_ceu_archive_course', array( $next, $end ) );
	}

	/**
	 * @param $results
	 *
	 * @return array
	 */
	public function normalize_course_data( $results ) {
		$return = array();
		if ( $results ) {
			//Add course progress
			foreach ( $results as $r ) {
				$user_id    = $r->user_id;
				$meta_key   = $r->meta_key;
				$meta_value = maybe_unserialize( $r->meta_value );

				if ( '_sfwd-course_progress' !== (string) $meta_key ) {
					continue;
				}
				$course_progress = $meta_value;
				if ( $course_progress ) {
					foreach ( $course_progress as $course_id => $progress ) {
						if ( (int) $progress['completed'] === (int) $progress['total'] ) {
							$return[ $user_id ][ $course_id ]             = array();
							$return[ $user_id ][ $course_id ]['progress'] = maybe_serialize( $progress );
						}
					}
				}
			}

			//Add course access from
			foreach ( $results as $r ) {
				$user_id    = $r->user_id;
				$meta_key   = $r->meta_key;
				$meta_value = maybe_unserialize( $r->meta_value );
				if ( strpos( $meta_key, '_access_from' ) ) {
					$course_id = (int) str_replace( 'course_', '', str_replace( '_access_from', '', $meta_key ) );
					if ( isset( $return[ $user_id ][ $course_id ] ) ) {
						$return[ $user_id ][ $course_id ]['access_from'] = $meta_value;
					} else {
						$return[ $user_id ][ $course_id ]['access_from'] = learndash_user_group_enrolled_to_course_from( $user_id, $course_id );
					}
				}
			}

			//Add course completed
			foreach ( $results as $r ) {
				$user_id    = $r->user_id;
				$meta_key   = $r->meta_key;
				$meta_value = maybe_unserialize( $r->meta_value );
				if ( strpos( $meta_key, '_completed_' ) ) {
					$course_id = (int) str_replace( 'course_completed_', '', $meta_key );
					if ( isset( $return[ $user_id ][ $course_id ] ) ) {
						$return[ $user_id ][ $course_id ]['completed'] = $meta_value;
					}
				}
			}

			//Add course certs
			foreach ( $results as $r ) {
				$user_id    = $r->user_id;
				$meta_key   = $r->meta_key;
				$meta_value = maybe_unserialize( $r->meta_value );
				if ( strpos( $meta_key, '-cert-' ) ) {
					$course_id = (int) str_replace( '_uo-course-cert-', '', $meta_key );
					if ( isset( $return[ $user_id ][ $course_id ]['completed'] ) ) {
						$completed = $return[ $user_id ][ $course_id ]['completed'];
						if ( is_array( $meta_value ) ) {
							foreach ( $meta_value as $certs ) {
								if ( key_exists( $completed, $certs ) ) {
									$return[ $user_id ][ $course_id ]['cert'] = $certs[ $completed ];
								}
							}
						}
					}
				}
			}
		}

		return $return;
	}

	/**
	 * @param $schedules
	 *
	 * @return mixed
	 */
	public function ceu_cron_schedules( $schedules ) {

		if ( ! isset( $schedules['per_minute'] ) ) {
			$schedules['per_minute'] = array(
				'interval' => 60,
				'display'  => __( 'Every one minute', 'uncanny-ceu' ),
			);
		}

		if ( ! isset( $schedules['every_two_minutes'] ) ) {
			$schedules['every_two_minutes'] = array(
				'interval' => 120,
				'display'  => __( 'Every two minutes', 'uncanny-ceu' ),
			);
		}

		return $schedules;
	}

}
