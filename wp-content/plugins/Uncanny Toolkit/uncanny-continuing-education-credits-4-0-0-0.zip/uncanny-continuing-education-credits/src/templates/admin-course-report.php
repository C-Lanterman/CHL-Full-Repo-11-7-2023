<?php

namespace uncanny_ceu;

if ( ! defined( 'WPINC' ) ) {
	die;
}

?>

<div class="wrap">
    <div class="ucec ucec-report">
        <?php

        // Add admin header and tabs
        $tab_active = 'uncanny-ceu-report';
        include Utilities::get_template( 'admin-header.php' );

        ?>

        <div class="ucec-report-toolbar">
            <div class="ucec-report-filters">
                <form method="GET">
                    <input type="hidden" value="<?php echo $_GET[ 'page' ]; ?>" name="page">

                    <div class="ucec-report-filter ucec-report-filter--dates">
                        <input type="hidden" name="start_date" id="ucec-date-range-custom-start"
							   value="<?php echo ( isset($_GET[ 'start_date' ])) ? $_GET[ 'start_date' ] : '' ; ?>">
                        <input type="hidden" name="end_date" id="ucec-date-range-custom-end"
							   value="<?php echo ( isset($_GET[ 'end_date' ])) ? $_GET[ 'end_date' ] : '' ; ?>">

                        <select name="date" id="ucec-date-range" class="ucec-report-select ucec-report-filter__select">
                            <?php echo BackendCourseReport::get_date_dropdown(); ?>
                        </select>
                    </div>
                    <div class="ucec-report-filter ucec-report-filter--users">
                        <select name="user" id="ucec-users" class="ucec-report-select ucec-report-filter__select">
                            <?php echo BackendCourseReport::get_users_dropdown(); ?>
                        </select>
                    </div>
                    <div class="ucec-report-filter ucec-report-filter--groups">
						<select name="group" id="ucec-groups" class="ucec-report-select ucec-report-filter__select">
							<?php echo BackendCourseReport::get_groups_dropdown(); ?>
						</select>
					</div>
					<div class="ucec-report-filter ucec-report-filter--courses">
						<select name="course" id="ucec-courses" class="ucec-report-select ucec-report-filter__select">
							<?php echo BackendCourseReport::get_courses_dropdown(); ?>
						</select>
					</div>

                    <div class="ucec-report-filter ucec-report-filter--submit">
                        <button type="submit" class="ucec-btn ucec-btn--primary">
                            <?php _e( 'Filter', 'uncanny-ceu' ); ?>
                        </button>
                    </div>
                </form>
            </div>
            <div class="ucec-report-actions">
                <div id="ucec-report-export-csv" class="ucec-btn ucec-btn--primary">
                    <?php _e( 'Export CSV', 'uncanny-ceu' ); ?>
                </div>
            </div>
        </div>

        <div class="ucec-report-results">
            <table id="ucec-course-report" class="ucec-report-results__table" data-csvfilename="<?php printf( '%s - %s', __( 'Credit Report', 'uncanny-ceu' ), date( 'Y-m-j g i A' ) ); ?>">
                <thead class="ucec-report-results-table__thead">
                    <tr class="ucec-report-results-table__tr">
						<th class="ucec-report-header-cell ucec-report-header-cell--checkbox"></th>
                        <th class="ucec-report-header-cell ucec-report-header-cell--user">
                            <?php _e( 'User', 'uncanny-ceu' ); ?>
                        </th>
                        <th class="ucec-report-header-cell ucec-report-header-cell--course">
                            <?php _e( 'Title', 'uncanny-ceu' ); ?>
                        </th>
                        <th class="ucec-report-header-cell ucec-report-header-cell--date">
                            <?php _e( 'Date', 'uncanny-ceu' ); ?>
                        </th>
                        <th class="ucec-report-header-cell ucec-report-header-cell--ceus-earned">
                            <?php echo Utilities::credit_designation_label('plural', __( 'CEUs', 'uncanny-ceu' ) ); ?>
                        </th>
                        <th class="ucec-report-header-cell ucec-report-header-cell--total">
                            <?php _e( 'Total', 'uncanny-ceu' ); ?>
                        </th>
                    </tr>
                </thead>
                <tbody class="ucec-report-results-table__tbody">
                   
                </tbody>
            </table>
        </div>
    </div>
</div>