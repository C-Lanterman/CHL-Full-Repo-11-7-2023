=== Uncanny Continuing Education Credits ===
Contributors: uncannyowl
Tags: LearnDash, eLearning, LMS, education, learning, courseware
Requires at least: 5.0
Tested up to: 6.1.1
Requires PHP: 7.2
Stable tag: 4.0
License: This plugin is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or any later version. Uncanny Continuing Education Credits is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.   You should have received a copy of the GNU General Public License along with Uncanny Continuing Education Credits. If not, see {URI to Plugin License}.
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html

Track CPD/CEU credits for your LearnDash courses.

== Description ==
**Important: This plugin requires PHP 7.2 or higher and LearnDash 4.0 or higher.**
