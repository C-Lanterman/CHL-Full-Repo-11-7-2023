Greetings! %First Name% %Last Name%,

Your Password is %Password%.
You've enrolled to our courses, %Courses%, and you are in the groups %Groups%.
