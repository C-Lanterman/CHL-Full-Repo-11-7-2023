export const UncannyLearnDashCodesPlaceholder = ({ children }) => {
	return (
		<div className="uo-learndash-codes-content">
			{ children }
		</div>
	);
}
