<?php
/**
 *
 */
const ULGM_ABSPATH = UNCANNY_GROUPS_PLUGIN . DIRECTORY_SEPARATOR;

/**
 *
 */
const ULGM_REST_API_PATH = 'ulgm_management/v1';
