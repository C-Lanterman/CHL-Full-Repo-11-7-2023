export const GroupsPlaceholder = ({ children }) => {
	return (
		<div className="uo-ult-groups-content">
			{ children }
		</div>
	);
}