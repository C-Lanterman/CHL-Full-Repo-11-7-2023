=== Uncanny Groups for LearnDash ===
Contributors: uncannyowl
Tags: LearnDash, eLearning, LMS, education, learning, courseware
Requires at least: 5.3
Tested up to: 6.2.2
Requires PHP: 7.4
Stable tag: 5.2.0.2
License: This plugin is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or any later version.   LearnDash Groups in User Profiles is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.   You should have received a copy of the GNU General Public License along with LearnDash Groups in User Profiles. If not, see {URI to Plugin License}.
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html

Allow LearnDash Group Leaders to manage group membership and licenses for LearnDash courses from the front end

== Description ==
**Important: This plugin requires PHP 7.4 or higher and LearnDash 4.2 or higher.**
